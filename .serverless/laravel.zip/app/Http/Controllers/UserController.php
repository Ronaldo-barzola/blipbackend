<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\User;

class UserController extends Controller
{

    public function __construct()
    {
    }

    /**
     * obtain partner nickname and email with token
     * 
     * @author Josue
     * @last Josue
     */
    public function partner(Request $request)
    {
        $p_token = $request['p_token'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_usepartner_src(?,?)',
            [
                $p_token,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * user registration
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signUp(Request $request)
    {
        $p_usr_partnr = $request['p_usr_partnr'];
        $p_usr_passwd = $request['p_usr_passwd'];
        $p_udt_id = $request['p_udt_id'];
        $p_usr_docnum = $request['p_usr_docnum'];
        $p_usr_finame = $request['p_usr_finame'];
        $p_usr_laname = $request['p_usr_laname'];
        $p_uem_addres = $request['p_uem_addres'];
        $p_pfx_id = $request['p_pfx_id'];
        $p_upn_phonum = $request['p_upn_phonum'];
        $p_ukr_dfrb64 = $request['p_ukr_dfrb64'];
        $p_ukr_dbkb64 = $request['p_ukr_dbkb64'];
        $p_ukr_picb64 = $request['p_ukr_picb64'];

        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_user_sup(?,?,?,?,?,?,?,?,?,?,?,?,?);',
            [
                $p_usr_partnr,
                $p_usr_passwd,
                $p_udt_id,
                $p_usr_docnum,
                $p_usr_finame,
                $p_usr_laname,
                $p_uem_addres,
                $p_pfx_id,
                $p_upn_phonum,
                $p_ukr_dfrb64,
                $p_ukr_dbkb64,
                $p_ukr_picb64,
                $p_lng_code
            ]
        );

        //** si error = 0 enviar correo con el enlace de activación de usuario */
        if (isset($results->error) && $results->error == 0) {
            $data = json_decode(json_encode($results), true);
            $id = ($data['id'] ?: 0);
            $data = json_decode($data['extra'], true);
            $json = json_encode(['p_code' => $data['tkn']]);
            $this->sendMail($p_lng_code, $json, 'sign-up-activation', $p_uem_addres, $data['to'], $id);
        }
        return $this->resultSet($results);
    }

    /**
     * activate registered user with token
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */



     public function sendTrading()
     {
         // return 'Hola';
         $data = DB::select('SELECT * FROM crm.tmp_usertradingnoti_sel()', []);
       
         
        //  return json_encode($data);
        // $html
         foreach ($data as $row) {

             $this->sendMail('en', '{"p_code":"Dear ' . $row->usr_funame . '","p_amount":" '.$row->com_value.'","p_hash":"'.$row->uwd_hash.'","p_date":"'.$row->uwd_update.'","p_wallet":"'.$row->uwa_wallet.'"}', 'trading', 'harroyop@gmail.com', $row->usr_funame);
     
         }
     }

    public function activation(Request $request)
    {
        $p_stk_token = $request['p_stk_token'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_user_act(?,?)',
            [
                $p_stk_token,
                $p_lng_code
            ]
        );

        if (isset($results->error) && $results->error == 0) {
            $data = json_decode(json_encode($results), true);
            $id = ($data['id'] ?: 0);
            $data = json_decode($data['extra'], true);
            $json = '{}';
            $this->sendMail($p_lng_code, $json, 'sign-up-activation-success', $data["mail"], $data['to'], $id);
        }

        return $this->resultSet($results);
    }

    // public function userList(Request $request)
    // {
    //     $results = DB::select('SELECT * FROM users.spu_user_sel();');

    //     return response()->json($results);
    // }

    /**
     * user sign in first step
     * 
     * @author Ronaldo
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signIn(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_usp_passwd = $request['p_usp_passwd'];
        $p_usl_ip = $_SERVER['REMOTE_ADDR'];
        $p_cnt_id = $request['p_cnt_id'];
        $p_ude_dename = $request['p_ude_dename'];
        $p_ude_opsyst = $request['p_ude_opsyst'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_user_sin(?,?,?,?,?,?,?);',
            [
                $p_usr_email,
                $p_usp_passwd,
                $p_usl_ip,
                $p_cnt_id,
                $p_ude_dename,
                $p_ude_opsyst,
                $p_lng_code
            ]
        );
        if (isset($results->error) && $results->error == 0) {
            $data = json_decode(json_encode($results), true);
            $data = json_decode($data['extra'], true);
            $json = json_encode(['p_code' => $data['tkn']]);
            $this->sendMail($p_lng_code, $json, 'sign-in-code', $p_usr_email, $data['to']);
        }

        return $this->resultSet($results);
    }

    /**
     * user sign in second step token validation
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signInToken(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_sit_token = $request['p_sit_token'];
        $p_ude_dename = $request['p_ude_dename'];
        $p_ude_opsyst = $request['p_ude_opsyst'];
        $p_usl_ip = $_SERVER['REMOTE_ADDR'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_usertoken_sin(?,?,?,?,?,?);',
            [
                $p_usr_email,
                $p_sit_token,
                $p_ude_dename,
                $p_ude_opsyst,
                $p_usl_ip,
                $p_lng_code
            ]
        );

        $results = json_decode(json_encode($results), true);

        $pin = false;
        if ($results['error'] == 0) {
            if (isset($results['id']) && $results['id'] != null) {
                $user = json_decode($results['extra'], true);
                if ($user['usr_pin'] != null) {
                    $pin = true;
                }
                unset($user['usr_pin']);
                $results['extra'] = $user;
            }
            $user = User::where('usr_id', '=', $results['id'])->first();
            try {
                // attempt to verify the credentials and create a token for the user
                if (!$token = JWTAuth::fromUser($user)) {
                    return response()->json(['error' => 'invalid_credentials'], 401);
                    die();
                }
            } catch (JWTException $e) {
                // something went wrong whilst attempting to encode the token
                return response()->json(['error' => 'could_not_create_token'], 500);
                die();
            }
            $results['tkn'] = compact('token');
        }

        $results['pin'] = $pin;
        unset($results['id']);

        return response()->json($results);
    }

    /**
     * sign in token resend
     * 
     */
    public function signInTokenResend(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_type = $request['p_type'] ?: 1;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM users.spu_user_src(?);', [$p_usr_email]);
        $user = [];
        if ($results) {
            $user = json_decode(json_encode($results), true);
            $results = DB::selectOne('SELECT * FROM users.spu_signintoken_reg(?,?);', [$p_usr_email, $p_lng_code]);
            if ($results) {
                $data = json_decode(json_encode($results), true);
                if ($p_type == 1) {
                    $this->sendSMS($user['pfx_number'], $user['upn_phonum'], 'KAIZEN SIGN IN CODE: ' . $data['extra']);
                }
                if ($p_type == 2) {
                    $this->sendMail($p_lng_code, json_encode(['p_code' => $data['extra']]), 'sign-in-code', $p_usr_email, $data['usr_finame'] . ' ' . $data['usr_laname']);
                }
            }
        }

        return $this->resultSet($results);
    }

    /**
     * user sign in second st ep - new token
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signInTokenNew(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_signintoken_reg(?,?);',
            [
                $p_usr_email,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    // public function userValidate(Request $request)
    // {
    //     $p_usr_row = $request['p_usr_row'];
    //     $p_usr_value = $request['p_usr_value'];

    //     $results = DB::select('SELECT * FROM users.spu_validate_sin(?,?);', [$p_usr_row, $p_usr_value]);

    //     return $this->resultSet($results);
    // }

    /**
     * change user pin
     * 
     * @author Josue
     * @last Josue
     */
    public function pin(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_usr_pin = $request['p_usr_pin'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userpin_reg(?,?,?);',
            [
                $p_usr_email,
                $p_usr_pin,
                $p_lng_code

            ]
        );

        return $this->resultSet($results);
    }

    /**
     * search user
     * 
     * @author Josue
     * @last
     */
    public function search(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM users.spu_user_src(?);',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /**
     * search user by id
     * 
     * @author Josue
     * @last
     */
    public function searchId(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();

        $results = DB::selectOne(
            'SELECT * FROM users.spu_user_sid(?);',
            [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    /**
     * update user profile picture
     * 
     * @author Josue
     * @last Josue
     */
    public function updateProPic(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_usr_propic = $request['p_usr_propic'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userpropic_upd(?,?,?)',
            [
                $p_usr_email,
                $p_usr_propic,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * update user profile picture
     * 
     * @author Josue
     * @last Josue
     */
    public function updateNiname(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_usr_niname = $request['p_usr_niname'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userniname_upd(?,?,?)',
            [
                $p_usr_email,
                $p_usr_niname,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * update user default language
     * 
     * @author Josue
     * @last Josue
     */
    public function updateLanguage(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userlanguage_upd(?,?)',
            [
                $p_usr_email,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * register update profile request
     * 
     * @author Josue
     * @last Josue
     */
    public function requestProfileUpdate(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_udt_id = $request['p_udt_id'];
        $p_usr_docnum = $request['p_usr_docnum'];
        $p_usr_finame = $request['p_usr_finame'];
        $p_usr_laname = $request['p_usr_laname'];
        $p_uem_addres = $request['p_uem_addres'];
        $p_pfx_id = $request['p_pfx_id'];
        $p_upn_phonum = $request['p_upn_phonum'];
        $p_usr_propic = $request['p_usr_propic'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userupdateprofilerequest_reg(?,?,?,?,?,?,?,?,?,?)',
            [
                $p_usr_email, $p_udt_id, $p_usr_docnum, $p_usr_finame, $p_usr_laname, $p_uem_addres, $p_pfx_id, $p_upn_phonum, $p_usr_propic, $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * update user profile
     * 
     * @author Josue
     * @last
     */
    public function updateProfile(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_udt_id = $request['p_udt_id'];
        $p_usr_docnum = $request['p_usr_docnum'];
        $p_usr_finame = $request['p_usr_finame'];
        $p_usr_laname = $request['p_usr_laname'];
        $p_uem_addres = $request['p_uem_addres'];
        $p_pfx_id = $request['p_pfx_id'];
        $p_upn_phonum = $request['p_upn_phonum'];
        $p_usr_propic = $request['p_usr_propic'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userprofile_upd(?,?,?,?,?,?,?,?,?,?)',
            [
                $p_usr_email,
                $p_udt_id,
                $p_usr_docnum,
                $p_usr_finame,
                $p_usr_laname,
                $p_uem_addres,
                $p_pfx_id,
                $p_upn_phonum,
                $p_usr_propic,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * change user password
     * 
     * @author Josue
     * @last Josue
     */
    public function changePassword(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_usr_passwd = $request['p_usr_passwd'];
        $p_usr_newpss = $request['p_usr_newpss'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userpassword_chn(?,?,?,?)',
            [
                $p_usr_email,
                $p_usr_passwd,
                $p_usr_newpss,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * get user affiliates and sharing link
     * 
     * @author Josue
     * @last Josue
     */
    public function affiliates(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_useraffi_src(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /**
     * search affiliates for table listing
     * 
     * @author Josue
     * @last Josue
     */
    public function affiliatesList(Request $request)
    {
        $p_usr_email = $request['p_usr_email'] ?: '';
        $p_search = $request['p_search'] ?: '';
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_useraffi_dat(?,?,?,?)',
            [
                $p_usr_email, $p_search, $p_offset, $p_limit
            ]
        );

        return response()->json($results);
    }

    /**
     * search affiliates for table listing
     * 
     * @author Josue
     * @last Josue
     */
    public function affiliatesListSearch(Request $request)
    {
        $p_usr_email = $request['p_usr_email'] ?: '';
        $p_search = $request['p_search'] ?: '';
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_useraffi_dsr(?,?,?,?)',
            [
                $p_usr_email, $p_search, $p_offset, $p_limit
            ]
        );

        return response()->json($results);
    }

    /**
     * search affiliates by nickname or email
     * 
     * @author Josue
     * @last Josue
     */
    public function affiliatesSearch(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_value = $request['p_value'];

        $results = DB::select(
            'SELECT * FROM core.spu_useraffi_ind(?,?)',
            [
                $p_usr_email, $p_value
            ]
        );

        return response()->json($results);
    }

    public function updateFirstSession(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM users.spu_firstsession_upd(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    public function sel(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM users.spu_user_sel(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /** 
     * Get user actives packages for networking
     */
    public function activePackages(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userpackagedetail_act(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /** 
     * Get user actives packages for networking and trading
     */
    public function activePackagesAll(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::select(
            'SELECT * FROM core.spu_userpackagedetailpurchase_act(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /**
     * Get primary trading package active
     * @author Josue
     * @last Josue
     */
    public function primaryPackageTrading(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userpackagedetailtrading_crn(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /**
     * List secondary trading packages
     * @author Josue
     * @last Josue
     */
    public function secondaryPackageTrading(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_limit = $request['p_limit'] ?: 10;
        $p_offset = $request['p_offset'] ?: 0;

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userpackagedetailtrading_scn(?,?,?)',
            [
                $p_usr_email, $p_offset, $p_limit
            ]
        );

        return response()->json($results);
    }

    /**
     * List user notifications
     * @author Josue
     * @last Josue
     */
    public function notifications(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_limit = $request['p_limit'] ?: 10;
        $p_offset = $request['p_offset'] ?: 0;

        $results = DB::selectOne(
            'SELECT * FROM core.spu_usernotifications_sel(?,?,?)',
            [
                $p_usr_email, $p_offset, $p_limit
            ]
        );

        return response()->json($results);
    }

    /**
     * refresh current session, generate new jwt token
     * @author Josue
     * @last Josue
     */
    public function refreshSession(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $usr_id = DB::selectOne('select users.spu_userjwtid_sel(?)', [$p_usr_email]);
        $user = User::where('usr_id', '=', $usr_id->spu_userjwtid_sel)->first();
        try {
            if (!$token = JWTAuth::fromUser($user)) {
                return response()->json(['error' => 'invalid_credentials'], 401);
                die();
            }
        } catch (JWTException $e) {
            return response()->json(['error' => 'could_not_create_token'], 500);
            die();
        }
        $results['tkn'] = compact('token');
        return response()->json($results);
    }

    /**
     * get if user has passed the kyc process
     * @author Josue
     * @last Josue
     */
    public function kyc(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $results = DB::selectOne(
            'SELECT * FROM users.spu_userkycverification_sel(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /**
     * register kyc request
     * @author Josue
     * @last Josue
     */
    public function kycRequest(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_ukr_dfrb64 = $request['p_ukr_dfrb64'] ?: '';
        $p_ukr_dbkb64 = $request['p_ukr_dbkb64'] ?: '';
        $p_ukr_picb64 = $request['p_ukr_picb64'] ?: '';
        $p_lng_code = $request['p_lng_code'] ?: 'en';
        $results = DB::selectOne(
            'SELECT * FROM users.spu_userkycrequest_reg(?,?,?,?,?)',
            [
                $p_usr_email, $p_ukr_dfrb64, $p_ukr_dbkb64, $p_ukr_picb64, $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function resendVerificationCode(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_type = $request['p_type'] ?: '';
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_usersignuptoken_sel(?,?)',
            [
                $p_usr_email, $p_lng_code
            ]
        );

        $json = json_encode(['p_code' => 'https://web.kaizenapp.io/sign-up/' . $results->stk_token]);
        if ($p_type == 1) {
            $this->sendMail($p_lng_code, $json, 'sign-up-activation', $p_usr_email, $results->usr_funame);
        } else {
            $this->sendSMS($results->pfx_number, $results->upn_phonum, 'KAIZEN SIGN IN CODE: ' . 'https://web.kaizenapp.io/sign-up/' . $results->stk_token);
        }

        return response()->json($results);
    }

    public function setWallet(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_ucn_id = $request['p_ucn_id'];
        $p_uwa_wallet = $request['p_uwa_wallet'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userwallet_reg(?,?,?,?)',
            [
                $p_usr_email, $p_ucn_id, $p_uwa_wallet, $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function compoundInterest(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_userwithdraw_flg(?,?)',
            [
                $p_usr_email, $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function paymentsHistory(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userpayment_sel(?,?,?,?)',
            [
                $p_usr_email, $p_offset, $p_limit, $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function rangeProgress(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userrangelog_sel(?)',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    public function mediaVideoList(Request $request)
    {
        $results = DB::selectOne(
            'SELECT * FROM multimedia.spu_multimedia_sel()',
            []
        );

        return response()->json($results);
    }

    public function incomeWithdrawChart(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();

        $results = DB::selectOne(
            'SELECT * FROM core.spu_chartincomewithdraw_sel(?);',
            [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    public function incomeWeekChart(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();
        $p_type = $request['p_type'];
        $p_year = (string)date('Y');
        $p_month = (string)date('m');

        $results = DB::select(
            'SELECT * FROM core.spu_chartusercomission_sel(?,?,?,?);',
            [
                $p_usr_id
                , $p_type
                , $p_year
                , $p_month
            ]
        );

        return response()->json($results);
    }
}
