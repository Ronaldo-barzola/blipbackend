<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\UserCRM;
use App\Http\Controllers\PaymentGatewayController;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class CrmMailingController extends Controller
{

    public function __construct()
    {
    }

    public function elementList(Request $request)
    {
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::select(
            'SELECT * FROM crm.spu_mailelementlanguage_sel(?);',
            [
                $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function imageList(Request $request)
    {

        $results = DB::select(
            'SELECT * FROM crm.spu_mailimages_sel();',
            []
        );

        return response()->json($results);
    }

    public function sendTest(Request $request)
    {
        $p_to_mail = $request['p_to_mail'];
        $p_to_name = $request['p_to_name'];
        $p_subject = $request['p_subject'];
        $p_body = $request['p_body'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';
        $mailParams = DB::selectOne('SELECT * FROM variable.spu_parammail_sel() AS mailjson;', []);
        $mailParams = json_decode(json_encode($mailParams), true);
        $mailParams = json_decode($mailParams['mailjson'], true);
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 0;
            $mail->CharSet = 'UTF-8';
            $mail->isSMTP();
            $mail->Host = $mailParams['mail-host'];
            $mail->SMTPAuth = true;
            $mail->Username = $mailParams['mail-username'];
            $mail->Password = $mailParams['mail-password'];
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('noreply@kaizenapp.io', $mailParams['mail-from']);
            $mail->addAddress($p_to_mail, $p_to_name);
            $mail->addReplyTo('noreply@kaizenapp.io', $mailParams['mail-from']);

            $mail->Subject = $p_subject;

            $mail->Body = $p_body;
            $mail->isHTML(true);

            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            if ($mail->send()) {
                $results = [ 'error' => 0, 'message' => 'Ok'];
                self::mailSentRegister(
                    0,
                    '',
                    $p_lng_code,
                    $p_to_mail,
                    $p_body,
                    $p_subject,
                    $p_to_name
                );
                return response()->json($results);
            } else {
                $results = [ 'error' => -500, 'message' => 'Internal Server Error', 'extra' => $mail->ErrorInfo];
                return response()->json($results);
            }
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            return false;
        }
    }

    public function sendCustom(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
        $p_to_mail = $request['p_to_mail'];
        $p_to_name = $request['p_to_name'];
        $p_subject = $request['p_subject'];
        $p_body = $request['p_body'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';
        $mailParams = DB::selectOne('SELECT * FROM variable.spu_parammail_sel() AS mailjson;', []);
        $mailParams = json_decode(json_encode($mailParams), true);
        $mailParams = json_decode($mailParams['mailjson'], true);
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 0;
            $mail->CharSet = 'UTF-8';
            $mail->isSMTP();
            $mail->Host = $mailParams['mail-host'];
            $mail->SMTPAuth = true;
            $mail->Username = $mailParams['mail-username'];
            $mail->Password = $mailParams['mail-password'];
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('noreply@kaizenapp.io', $mailParams['mail-from']);
            $mail->addAddress($p_to_mail, $p_to_name);
            $mail->addReplyTo('noreply@kaizenapp.io', $mailParams['mail-from']);

            $mail->Subject = $p_subject;

            $mail->Body = $p_body;
            $mail->isHTML(true);

            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            if ($mail->send()) {
                $results = [ 'error' => 0, 'message' => 'Ok'];
                self::mailSentRegister(
                    $p_usr_id,
                    '',
                    $p_lng_code,
                    $p_to_mail,
                    $p_body,
                    $p_subject,
                    $p_to_name
                );
                return response()->json($results);
            } else {
                $results = [ 'error' => -500, 'message' => 'Internal Server Error', 'extra' => $mail->ErrorInfo];
                return response()->json($results);
            }
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            return false;
        }
    }

    public function mailSentList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 0;

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_mailsent_sel(?,?,?,?,?,?,?)'
            , [
                $p_search
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function mailBulkList(Request $request)
    {
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 0;

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_mailbulk_sel(?,?,?,?,?,?)'
            , [
                $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function mailBulkSearch(Request $request)
    {
        $p_mbl_id = $request['p_mbl_id'] ?: 0;

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_mailbulk_src(?)'
            , [
                $p_mbl_id
            ]
        );

        return response()->json($results);
    }

    public function mailQueryCriteriaList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';

        $results = DB::select(
            'SELECT * FROM mail.spu_mailquerycriteria_sel(?)'
            , [
                $p_search
            ]
        );

        return response()->json($results);
    }

    public function mailQueryCriteriaExecute(Request $request)
    {
        $p_mqc_id = $request['p_mqc_id'];
        $p_params = $request['p_params'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM mail.spu_mailquerycriteria_exc(?,?,?)'
            , [
                $p_mqc_id
                , $p_params
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function mailBulkRegister(Request $request)
    {
        $p_mqc_id = $request['p_mqc_id'];
        $p_mbl_params = $request['p_mbl_params'];
        $p_mbl_format = $request['p_mbl_format'];
        $p_lng_code = $request['p_lng_code'];
        $p_users = $request['p_users'];

        $results = DB::selectOne(
            'SELECT * FROM mail.spu_mailbulk_reg(?,?,?,?,?)'
            , [
                $p_mqc_id
                , $p_mbl_params
                , $p_mbl_format
                , $p_users
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function sendCustomBulk(Request $request)
    {
        $p_mbl_id = $request['p_mbl_id'];
        $p_usr_id = $request['p_usr_id'];
        $p_to_mail = $request['p_to_mail'];
        $p_to_name = $request['p_to_name'];
        $p_subject = $request['p_subject'];
        $p_body = $request['p_body'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';
        $mailParams = DB::selectOne('SELECT * FROM variable.spu_parammail_sel() AS mailjson;', []);
        $mailParams = json_decode(json_encode($mailParams), true);
        $mailParams = json_decode($mailParams['mailjson'], true);
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPDebug = 0;
            $mail->CharSet = 'UTF-8';
            $mail->isSMTP();
            $mail->Host = $mailParams['mail-host'];
            $mail->SMTPAuth = true;
            $mail->Username = $mailParams['mail-username'];
            $mail->Password = $mailParams['mail-password'];
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('noreply@kaizenapp.io', $mailParams['mail-from']);
            $mail->addAddress($p_to_mail, $p_to_name);
            $mail->addReplyTo('noreply@kaizenapp.io', $mailParams['mail-from']);

            $mail->Subject = $p_subject;

            $mail->Body = $p_body;
            $mail->isHTML(true);

            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            if ($mail->send()) {
                $results = DB::selectOne('SELECT * FROM mail.spu_mailsentbulk_reg(?,?,?,?,?,?,?);', 
                    [
                        $p_mbl_id
                        , $p_usr_id
                        , $p_lng_code
                        , $p_to_mail
                        , $p_body
                        , $p_subject
                        , $p_to_name
                    ]
                );
                return response()->json($results);
            } else {
                $results = [ 'error' => -500, 'message' => 'Internal Server Error', 'extra' => $mail->ErrorInfo];
                return response()->json($results);
            }
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            return false;
        }
    }

    public function mailBulkFinish(Request $request)
    {
        $p_mbl_id = $request['p_mbl_id'];

        $results = DB::selectOne(
            'SELECT * FROM mail.spu_mailbulk_fin(?)'
            , [
                $p_mbl_id
            ]
        );

        return response()->json($results);
    }

}
