<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Http\Request;

use Intervention\Image\Facades\Image;

class AssetsController extends Controller
{

    public function __construct()
    {

    }

    public static function mail(Request $request)
    {
        $sub = $request->route('sub');
        $asset = $request->route('file');
        $storagePath = storage_path('/assets/images/mail/' . $sub . '/' . $asset);

        return Image::make($storagePath)->response();
    }

    // public static function 

}
