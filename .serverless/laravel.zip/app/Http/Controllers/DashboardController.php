<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\User;

class DashboardController extends BaseController
{

    public function __construct()
    {

    }

    /**
     * get user networking affiliates pie chart values
     * 
     * @author Josue
     * @last Josue
     */
    public function networkingPie(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::select('SELECT * FROM core.spu_chartnetworking_sel(?);', [$p_usr_email]);

        return response()->json($results);
    }

    /**
     * get user networking bonus line chart values
     * 
     * @author Josue
     * @last Josue
     */
    public function networkingBonusLine(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_month = $request['p_month'];
        $p_year = $request['p_year'];

        $results = DB::select('SELECT * FROM core.spu_chartnetworkingbonus_sel(?,?,?);', [$p_usr_email, $p_month, $p_year]);

        return response()->json($results);
    }

    /**
     * get user daily trading bonus line chart values
     * 
     * @author Josue
     * @last Josue
     */
    public function tradingDailyLine(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_month = $request['p_month'];
        $p_year = $request['p_year'];

        $results = DB::select('SELECT * FROM core.spu_charttradingdaily_sel(?,?,?);', [$p_usr_email, $p_month, $p_year]);

        return response()->json($results);
    }

    public function tradingDailyProfit(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM core.spu_charttradingdaily_sel(?,?,?);'
            , [
                $p_usr_email
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function tradingDailyList(Request $request) {
        $p_usr_email = $request['p_usr_email'];
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne('SELECT * FROM core.spu_usertraidingdaily_sel(?,?,?,?);'
            , [
                $p_usr_email
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function networkingDailyProfit(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM core.spu_chartnetworking_sel(?,?,?);'
            , [
                $p_usr_email
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function networkingProfitsHistory(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne('SELECT * FROM core.spu_comissionnetworking_sel(?,?,?,?);'
            , [
                $p_usr_email
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function tradingMonthWeekProfit(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();
        // $p_usr_id = 713;    

        $p_year = date('Y');
        $p_month = date('m');

        $results = DB::select('SELECT * FROM core.spu_chartusertradingweek_sel(?,?,?);'
            , [
                $p_usr_id
                , $p_year
                , $p_month
            ]
        );

        return response()->json($results);
    }

    public function affiliatesResume(Request $request)
    {
        // $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();
        $p_usr_id = 6;

        $results = DB::selectOne('SELECT * FROM core.spu_useraffi_rsm(?);'
            , [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

}