<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\User;

class ByBitController extends BaseController
{

    public function __construct()
    {

    }

    /**
     * register bybit account test
     * @author Josue
     * @last Josue
     */
    public function accountRegister(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();
        $p_uba_key = $request['p_uba_key'];
        $p_uba_secret = $request['p_uba_secret'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM bybit.spu_userbybitaccount_reg(?,?,?,?);'
            , [
                $p_usr_id
                , $p_uba_key
                , $p_uba_secret
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    /**
     * search bybit credentials by user id
     * @author Josue
     * @last Josue
     */
    public function accountSearch(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();

        $results = DB::selectOne(
            'SELECT * FROM bybit.spu_userbybitaccount_src(?);'
            , [
                $p_usr_id
            ]
        );

        if ($results) {
            $results = json_decode(json_encode($results), true);
            $results['uba_secret'] = '*****';
        }

        return response()->json($results);
    }

    /**
     * search bybit credentials by user id
     * @author Josue
     * @last Josue
     */
    public function accountSecretSearch(Request $request)
    {
        $p_usr_id = JWTAuth::toUser(JWTAuth::getToken())->getJWTIdentifier();
        $token = $request['token'];

        $tokenval = DB::selectOne(
            'SELECT * FROM bybit.spu_bybitauthtoken_val(?);'
            , [
                $token
            ]
        );

        if ($tokenval->error == 0) {
            $results = DB::selectOne(
                'SELECT * FROM bybit.spu_userbybitaccount_src(?);'
                , [
                    $p_usr_id
                ]
            );
    
            return response()->json($results);
        } else {
            return response()->json($tokenval);
        }
    }


    /**
     * select bybit account with token
     * @author Josue
     * @last Josue
     */
    public function accountList(Request $request)
    {
        $token = $request['token'];
        $p_lng_code = 'en';

        $results = DB::selectOne(
            'SELECT * FROM bybit.spu_bybitauthtoken_sel(?,?);'
            , [
                $token
                , $p_lng_code
            ]
        );
        $results = json_decode(json_encode($results), true);
        if (isset($results['error'])) {
            if ($results['error'] == 0) {
                $results = [
                    'error' => $results['error']
                    , 'message' => $results['message']
                    , 'data' => json_decode($results['extra'])
                ];
            } else {
                $results = [
                    'error' => $results['error']
                    , 'message' => $results['message']
                ];
            }
        }

        return response()->json($results);
    }



}