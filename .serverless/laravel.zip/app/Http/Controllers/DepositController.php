<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class DepositController extends Controller
{

    public function __construct()
    {

    }

    /**
     * list available packages for desposit
     * 
     * @author Josue
     * @last Josue
     */
    public function available(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::select   ('SELECT * FROM core.spu_userpackagedetaildepositavailable_sel(?);', [$p_usr_email]);

        return response()->json($results);
    }

    /**
     * start investment deposit
     * 
     * @author Josue
     * @last Josue
     */
    public function start(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_upa_id = $request['p_upa_id'];
        $p_ucn_id = $request['p_ucn_id'];
	    $p_wpy_amount = $request['p_wpy_amount'];
	    $p_wpy_usdamo = $request['p_wpy_usdamo'];
	    // $p_wpy_waladd = $request['p_wpy_waladd'];
        $p_wpy_waladd = self::generateRandomString(20);
	    $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_tradingdeposit_str(?,?,?,?,?,?,?);', [
            $p_usr_email
            , $p_upa_id
            , $p_ucn_id
            , $p_wpy_amount
            , $p_wpy_usdamo
            , $p_wpy_waladd
            , $p_lng_code
        ]);

        return response()->json($results);
    }

    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    /**
     * get deposit history
     * 
     * @author Josue
     * @last Josue
     */
    public function history(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_tradingdeposit_sel(?,?,?,?);', 
            [
                $p_usr_email
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

}