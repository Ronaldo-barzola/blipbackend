<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class CoreController extends BaseController
{

    public function __construct()
    {
    }

    public function packageSel(Request $request)
    {
        $p_pck_id = $request['p_pck_id'];
        $results = DB::select('SELECT * FROM core.spu_package_sel(?);', [$p_pck_id]);
        return response()->json($results);
    }

    public function packagePrc(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $results = DB::select('SELECT * FROM core.spu_package_prc(?);', [$p_usr_email]);
        return response()->json($results);
    }

    public function packageUpg(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $results = DB::select('SELECT * FROM core.spu_package_upg(?);', [$p_usr_email]);
        return response()->json($results);
    }

}