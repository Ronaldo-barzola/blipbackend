<?php

namespace App\Http\Controllers;


use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;
use Twilio\Rest\Client;
use Illuminate\Http\Request;
use App\Http\Controllers\SendMailController;

class SmsController extends Controller
{

    function getCredentials()
    {
        $results = DB::select('SELECT * FROM variable.spu_paramsms_sel();');
        return $results;
    }

    public function send(Request $request)
    {
        $credentials = self::getCredentials();
        $datos = json_decode($credentials[0]->spu_paramsms_sel);

        $p_prefix = $request['p_prefix'];
        $p_phone = $request['p_phone'];
        $p_body = $request['p_body'];

        $sid = $datos->{'sms-id'};
        $token = $datos->{'sms-token'};
        $msg_service = $datos->{'sms-service-id'};
        $twilio = new Client($sid, $token);

        $message = $twilio->messages
            ->create(
                '+' . $p_prefix . $p_phone,
                array(
                    'messagingServiceSid' => $msg_service,
                    'body' => $p_body,
                )
            );

        print($message->sid);

    }

}