<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\UserCRM;
use App\Http\Controllers\PaymentGatewayController;

class CrmController extends Controller
{

    public function __construct()
    {
    }

        /**
     * user sign in first step
     * 
     * @author Ronaldo
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signIn(Request $request)
    {
        $p_usr_name = $request['p_usr_name'];
        $p_usr_passwd = $request['p_usr_passwd'];
        $p_ses_time = 0;
        $p_ses_token = '';
        $p_ses_dename = $request['p_ses_dename'];
        $p_ses_ipaddr = $_SERVER['REMOTE_ADDR'];
        $p_ses_opsyst = $request['p_ses_opsyst'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_user_val(?,?);',
            [
                $p_usr_name
                , $p_usr_passwd
            ]
        );
        $results = json_decode(json_encode($results), true);
        $id = 0;
        if ($results) {
            if ($results['error'] == 0) {
                $id = $results['id'];
                $user = UserCRM::where('usr_id', '=', $id)->first();
                try {
                    // attempt to verify the credentials and create a token for the user
                    config()->set('jwt.ttl', 60*12);
                    if (!$token = JWTAuth::fromUser($user)) {
                        return response()->json(['error' => 'invalid_credentials'], 401);
                        die();
                    }
                } catch (JWTException $e) {
                    // something went wrong whilst attempting to encode the token
                    return response()->json(['error' => 'could_not_create_token'], 500);
                    die();
                }
                $p_ses_token = compact('token');

                $results = DB::selectOne(
                    'SELECT * FROM crm.spu_user_sin(?,?,?,?,?,?,?,?);',
                    [
                        $p_usr_name
                        , $p_usr_passwd
                        , $p_ses_time
                        , $p_ses_token['token']
                        , $p_ses_dename
                        , $p_ses_ipaddr
                        , $p_ses_opsyst
                        , $p_lng_code
                    ]
                );
                $results = json_decode(json_encode($results), true);
                if ($results) {
                    if ($results['error'] == 0) {
                        $results['token'] = $p_ses_token['token'];
                        $menuAccess = DB::selectOne(
                            'SELECT * FROM crm.spu_userprofilemenu_sel(?);',
                            [
                                $id
                            ]
                        );
                        $menuAccess = json_decode(json_encode($menuAccess), true);
                        $menuAccess["jso_men"] = json_decode($menuAccess["jso_men"], true) ?: [];
                        $menuAccess["jso_pag"] = json_decode($menuAccess["jso_pag"], true) ?: [];
                        if ($menuAccess["jso_men"]) {
                            foreach ($menuAccess["jso_men"] as $i => $row ) {
                                if ($row["men_flgcol"]) {
                                    $menuAccess["jso_men"][$i]["submenu"] = self::subMenu($row, $id);
                                }
                            }
                        }
                        $results['menu'] = $menuAccess;
                    }
                }
            }
        } else {
            $results = [
                'error' => 500
                , 'message' => 'Internal Server Error'
            ];
        }
        return response()->json($results);
    }

    private function subMenu($row, $id) {
        $submenu = DB::select(
            'SELECT * FROM crm.spu_crmmenu_sel(?,?);',
            [
                $id
                , $row["men_id"]
            ]
        );
        $submenu = json_decode(json_encode($submenu), true);
        foreach ($submenu as $i => $row2) {
            if ($row2["men_flgcol"]) {
                $submenu[$i]["submenu"] = self::subMenu($row2, $id);
            }
        }
        return $submenu;
    }
    
    public function crmNotifications(Request $request)
    {
        $results = DB::selectOne('SELECT * FROM crm.spu_crmnotification_sel();', []);

        return response()->json($results);
    }

    public function panelTradingDailyList(Request $request)
    {
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_tradingdaily_sel(?,?,?,?,?);', 
            [
                $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function panelTradingDailyReport(Request $request)
    {
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM crm.spu_tradingdaily_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function panelTradingDailyChart(Request $request)
    {
        $p_date = $request['p_date'];

        $results = DB::select('SELECT * FROM crm.spu_charttradingdailytaken_sel(?);', 
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    public function panelCryptoStatusChart(Request $request)
    {
        $p_date = $request['p_date'];

        $results = DB::selectOne('SELECT * FROM crm.spu_chartcryptostatus_sel(?);', 
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    /**
     * get all kyc requests
     * 
     * @author Josue
     * @last Josue
     */
    public function kycRequests(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userkycrequest_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    /**
     * get kyc request by id
     * 
     * @author Josue
     * @last Josue
     */
    public function kycRequestSearch(Request $request)
    {
        $p_ukr_id = $request['p_ukr_id'];

        $results = DB::selectOne('SELECT * FROM crm.spu_userkycrequest_src(?);',
            [
                $p_ukr_id
            ]
        );

        return response()->json($results);
    }

    /**
     * approve selected request
     * 
     * @author Josue
     * @last Josue
     */
    public function kycRequestApprove(Request $request)
    {
        $p_ukr_id = $request['p_ukr_id'];
        $p_ukr_usrupd = $request['p_ukr_usrupd'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM users.spu_userkycrequest_apb(?,?,?);', 
            [
                $p_ukr_id
                , $p_ukr_usrupd
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * deny selected request
     * 
     * @author Josue
     * @last Josue
     */
    public function kycRequestDeny(Request $request)
    {
        $p_ukr_id = $request['p_ukr_id'];
        $p_ukr_usrupd = $request['p_ukr_usrupd'];
        $p_ukr_flgdfr = $request['p_ukr_flgdfr'];
	    $p_ukr_flgdbk = $request['p_ukr_flgdbk'];
	    $p_ukr_flgpic = $request['p_ukr_flgpic'];
        $p_ukr_observ = $request['p_ukr_observ'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM users.spu_userkycrequest_dny(?,?,?,?,?,?,?);', 
            [
                $p_ukr_id
                , $p_ukr_usrupd
                , $p_ukr_flgdfr
                , $p_ukr_flgdbk
                , $p_ukr_flgpic
                , $p_ukr_observ
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    public function kycRequestReport(Request $request)
    {
        $p_type = $request['p_type'];
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM crm.spu_userkycrequest_rpt(?,?,?);', 
            [
                $p_type
                , $p_start
                , $p_end
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * get all profile update requests
     * 
     * @author Josue
     * @last Josue
     */
    public function profileUpdateRequests(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userupdateprofilerequest_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    /**
     * get all profile update requests
     * 
     * @author Josue
     * @last Josue
     */
    public function profileUpdateRequestSearch(Request $request)
    {
        $p_upr_id = $request['p_upr_id'];

        $results = DB::selectOne('SELECT * FROM crm.spu_userupdateprofilerequest_src(?);',
            [
                $p_upr_id
            ]
        );

        return response()->json($results);
    }

    /**
     * approve selected request
     * 
     * @author Josue
     * @last Josue
     */
    public function profileUpdateRequestApprove(Request $request)
    {
        $p_upr_id = $request['p_upr_id'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM users.spu_userupdateprofilerequest_acp(?,?);', 
            [
                $p_upr_id
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * deny selected request
     * 
     * @author Josue
     * @last Josue
     */
    public function profileUpdateRequestDeny(Request $request)
    {
        $p_upr_id = $request['p_upr_id'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM users.spu_userupdateprofilerequest_dny(?,?);', 
            [
                $p_upr_id
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    public function profileUpdateRequestsReport(Request $request)
    {
        $p_type = $request['p_type'];
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM crm.spu_userupdateprofilerequest_rpt(?,?,?);', 
            [
                $p_type
                , $p_start
                , $p_end
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * get all withdraw requests
     * 
     * @author Josue
     * @last Josue
     */
    public function withdrawRequests(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_withdrawrequest_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    /**
     * approve selected request
     * 
     * @author Josue
     * @last Josue
     */
    public function withdrawRequestApprove(Request $request)
    {
        $p_wdr_id = $request['p_wdr_id'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_withdrawrequest_apb(?,?);', 
            [
                $p_wdr_id
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }
    
    /**
     * deny selected request
     * 
     * @author Josue
     * @last Josue
     */
    public function withdrawRequestDeny(Request $request)
    {
        $p_wdr_id = $request['p_wdr_id'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_withdrawrequest_den(?,?);', 
            [
                $p_wdr_id
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * export approved requests
     * 
     * @author Josue
     * @last Josue
     */
    public function withdrawRequestReport(Request $request)
    {
        $p_dtstart = $request['p_dtstart'];
        $p_dtend = $request['p_dtend'];

        $results = DB::select('SELECT * FROM crm.spu_withdrawrequest_rpt(?,?);', 
            [
                $p_dtstart
                , $p_dtend
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * List crypto status
     * 
     * @author Josue
     * @last Josue
     */
    public function cryptoStatusDayList(Request $request)
    {
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_cryptostatusday_sel(?,?,?,?,?);', 
            [
                $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    /**
     * Register crypto status by date range
     * 
     * @author Josue
     * @last Josue
     */
    public function cryptoStatusDayRegister(Request $request)
    {
        $p_csd_datest = $request['p_csd_datest'];
        $p_csd_datend = $request['p_csd_datend'];
        $p_csd_valmin = $request['p_csd_valmin'];
        $p_csd_valmax = $request['p_csd_valmax'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_cryptostatusday_reg(?,?,?,?,?);', 
            [
                $p_csd_datest
                , $p_csd_datend
                , $p_csd_valmin
                , $p_csd_valmax
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    /**
     * List trading bot crypto status
     * 
     * @author Josue
     * @last Josue
     */
    public function cryptoStatusList(Request $request)
    {
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_cryptostatus_sel(?,?,?,?,?);', 
            [
                $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function panelMotherAccountBonusList(Request $request)
    {
        $p_date = $request['p_date'];
        $p_order_type = $request['p_order_type'];
        $p_order = $request['p_order'];
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_kaizenbonus_sel(?,?,?,?,?,?);', 
            [
                $p_date
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function panelMotherAccountBonusChart(Request $request)
    {
        $p_date = $request['p_date'];

        $results = DB::select('SELECT * FROM crm.spu_chartkaizenbonus_sel(?);',
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    public function panelMotherAccountBonusReport(Request $request)
    {
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM crm.spu_kaizenbonus_rpt(?,?);',
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function accountingDiscountsReport(Request $request)
    {
        $p_upd_active = $request['p_active'];

        $results = DB::select('SELECT * FROM crm.spu_userpaymentdiscount_rpt(?);', 
            [
                $p_upd_active
            ]
        );

        return response()->json($results);
    }

    public function accountingDiscountsList(Request $request)
    {
        $p_upd_active = $request['p_active'];
        $p_order_type = $request['p_order_type'];
        $p_order = $request['p_order'];
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userpaymentdiscount_sel(?,?,?,?,?,?);', 
            [
                $p_upd_active
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function accountingDepositsReport(Request $request)
    {
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userdeposits_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function accountingPaymentsReport(Request $request)
    {
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userpayments_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function panelDepositDayList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_date = $request['p_date'] ?: '';
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_walletpayment_sel(?,?,?,?,?,?,?);', 
            [
                $p_date
                , $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function panelDepositDayChart(Request $request)
    {
        $p_date = $request['p_date'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_chartwalletpayment_sel(?);', 
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    public function panelDepositMonthChart(Request $request)
    {
        $p_year = $request['p_year'];
        $p_month = $request['p_month'];

        $results = DB::select('SELECT * FROM crm.spu_chartwalletpaymentday_sel(?,?);', 
            [
                $p_year
                , $p_month
            ]
        );

        return response()->json($results);
    }

    public function panelDepositDayReport(Request $request)
    {
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_walletpayment_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }
    
    public function panelUserComissionList(Request $request)
    {
        $p_date = $request['p_date'];
        $p_order_type = $request['p_order_type'];
        $p_order = $request['p_order'];
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userbonus_sel(?,?,?,?,?,?);', 
            [
                $p_date
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function panelUserComissionChart(Request $request)
    {
        $p_date = $request['p_date'];

        $results = DB::select('SELECT * FROM crm.spu_chartuserbonus_sel(?);',
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    public function panelUserComissionReport(Request $request)
    {
        $p_start = $request['p_start'];
        $p_end = $request['p_end'];

        $results = DB::select('SELECT * FROM crm.spu_paneluserbonus_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function accountingPaymentsList(Request $request)
    {
        $p_date = $request['p_date'] ?: '';
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userpayment_sel(?,?,?,?,?,?,?);', 
            [
                $p_date
                , $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function bulkPendingsList(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userdepositspending_sel(?,?,?,?,?,?,?);', 
            [
                $p_type
                , $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function bulkPendingsChart(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $results = DB::selectOne('SELECT * FROM crm.spu_chartbulkpaymentpending_sel(?);', 
            [
                $p_type
            ]
        );

        return response()->json($results);
    }

    public function bulkPendingsReport(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $results = DB::select('SELECT * FROM crm.spu_userdepositspending_rpt(?);', 
            [
                $p_type
            ]
        );

        return response()->json($results);
    }

    public function bulkVal(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $results = DB::selectOne('SELECT * FROM crm.spu_depositbulk_val(?);', 
            [
                $p_type
            ]
        );

        return response()->json($results);
    }

    public function bulkRegister(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $results = DB::selectOne('SELECT * FROM crm.spu_depositbulk_reg(?);', 
            [
                $p_type
            ]
        );

        return response()->json($results);
    }

    public function bulkList(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_depositsbulk_sel(?,?,?,?,?,?);', 
            [
                $p_type
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function bulkDet(Request $request){
        $p_blk_id = $request['p_blk_id'];

        $results = DB::select('SELECT * FROM crm.spu_depositsbulk_lst(?);', 
            [
                $p_blk_id
            ]
        );

        return response()->json($results);
    }

    public function bulkDetFee(Request $request){
        $p_blk_id = $request['p_blk_id'];

        $results = DB::select('SELECT * FROM crm.spu_depositsbulk_det(?);', 
            [
                $p_blk_id
            ]
        );

        return response()->json($results);
    }

    public function bulkSetPay(Request $request){
        $p_blk_id = $request['p_blk_id'];

        $results = DB::select('SELECT * FROM crm.spu_depositbulk_cnf(?);', 
            [
                $p_blk_id
            ]
        );

        return response()->json($results);
    }

    public function bulkUpdateHash(Request $request){
        $p_usr_id = $request['p_usr_id'];
        $p_blk_id = $request['p_blk_id'];
        $p_uwd_hash = $request['p_uwd_hash'];

        $results = DB::select('SELECT * FROM crm.spu_deposituserbulk_cnf(?,?,?);', 
            [
                $p_usr_id,
                $p_blk_id,
                $p_uwd_hash
            ]
        );

        return response()->json($results);
    }

    public function bulkSend(Request $request)
    {
        $client_id = "oacid-cldylmhk10mai1nis1otoea99";
        $client_secret = "c3804fe1374b6b675e24ebf0de2a9571bd5fc20d5f5b2d0aeab6e237c0be3d13";
        $merchant_key = "mkey-cldylmhjv0mah1nis1ofh00j4";
        $grant_type = "client_credentials";

        $p_blk_id = $request['p_blk_id'];

        //LISTAR USUARIOS CON SU PAGO CORRESPONDIENTES
        $results = DB::select('SELECT * FROM crm.spu_depositsbulk_det(?);', 
            [
                $p_blk_id
            ]
        );
        $data = json_decode(json_encode($results), true); //data

        //PROCESO ENVIO BULK DESDE LA WALLET
        
        foreach($data as $i => $row){ 
            $amount = $row['uwd_amount'];
            $payer_id = $row['uem_addres'];
            $client_wallet = $row['uwa_wallet'];
            $merchant_key = $merchant_key;            

            $curl = curl_init();

            curl_setopt_array($curl, [
                CURLOPT_URL => "https://api.triple-a.io/api/v2/payout/withdraw/local/crypto/direct",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => '{
                    "merchant_key": "'.$merchant_key.'",
                    "email": "'.$payer_id.'",
                    "withdraw_currency": "USD",
                    "withdraw_amount": "'.$amount.'",
                    "crypto_currency": "testBTC",
                    "remarks": "A Testing App Bonus Payout",
                    "address": "'.$client_wallet.'",
                    "name": "Testing App",
                    "country": "MX"}',
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer '.$token,
                    'Content-Type: application/json'
                ],
            ]);

            $response = curl_exec($curl);

            $response = curl_exec($curl);
            $error = curl_error($curl);

            curl_close($curl);

            $resultado_bulk = json_decode($response, true);

            $results = DB::selectOne('SELECT * FROM crm.spu_bulkpayout_reg(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);', 
            [
                $resultado_bulk['order_id'],
                $resultado_bulk['payout_reference'],
                $resultado_bulk['type'],
                $resultado_bulk['account_type'],
                $resultado_bulk['convert_type'],
                $resultado_bulk['local_currency'],
                $resultado_bulk['local_amount'],
                $resultado_bulk['crypto_currency'],
                $resultado_bulk['crypto_amount'],
                $resultado_bulk['network_fee_crypto_amount'],
                $resultado_bulk['net_crypto_amount'],
                $resultado_bulk['crypto_address'],
                $resultado_bulk['exchange_rate'],
                $resultado_bulk['status'],
                $resultado_bulk['status_date'],
                $resultado_bulk['merchant_name'],
                $resultado_bulk['remarks'],
                $resultado_bulk['notify_url'],
                $resultado_bulk['notify_secret'],
            ]
        );

        }

        //CONFIRMAR BULK PAGADO
        $results = DB::selectOne('SELECT * FROM crm.spu_depositbulk_cnf(?);', 
            [
                $p_blk_id
            ]
        );

        return response()->json($results);
    }
    
    public function userList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_user_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function userSearch(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;

        $results = DB::selectOne('SELECT * FROM crm.spu_user_src(?);', 
            [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    public function userRegisterList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userregister_sel(?,?,?,?,?,?,?,?);', 
            [
                $p_search
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function userRegisterReport(Request $request)
    {
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userregister_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function userRegisterYearChart(Request $request)
    {
        $p_year = $request['p_year'] ?: date('Y');

        $results = DB::select('SELECT * FROM crm.spu_chartuserregiseryear_sel(?);', 
            [
                $p_year
            ]
        );

        return response()->json($results);
    }

    public function userRegisterMonthChart(Request $request)
    {
        $p_year = $request['p_year'] ?: date('Y');
        $p_month = $request['p_month'] ?: date('m');

        $results = DB::select('SELECT * FROM crm.spu_chartuserregisermonth_sel(?,?);', 
            [
                $p_year
                , $p_month
            ]
        );

        return response()->json($results);
    }

    public function userAffiliates(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;

        $results = DB::selectOne('SELECT * FROM crm.spu_useraffi_dat(?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function userAffiliatesReport(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;

        $results = DB::select('SELECT * FROM crm.spu_useraffi_rpt(?);', 
            [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    public function userBonuses(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;

        $results = DB::selectOne('SELECT * FROM crm.spu_userbonus_dat(?,?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function userBonusesReport(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userbonus_rpt(?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }
    
    public function userPurchases(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userwalletpayment_dat(?,?,?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function userPurchasesReport(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userwalletpayment_rpt(?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function userPurchasesPending(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userwalletpaymentpending_dat(?,?,?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function userPurchasesPendingReport(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userwalletpaymentpending_rpt(?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function userPayments(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;

        $results = DB::selectOne('SELECT * FROM crm.spu_userpayment_dat(?,?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function userPaymentsReport(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userpayment_rpt(?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function userDiscounts(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;

        $results = DB::selectOne('SELECT * FROM crm.spu_userdiscounts_dat(?,?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function userDiscountsReport(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userdiscounts_rpt(?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function userDiscountsRegister(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
        $p_upd_curamo = $request['p_upd_curamo'];
        $p_upd_observ = $request['p_upd_observ'] ?: '';

        $results = DB::selectOne('SELECT * FROM crm.spu_userdiscounts_reg(?,?,?);', 
            [
                $p_usr_id
                , $p_upd_curamo
                , $p_upd_observ
            ]
        );

        return response()->json($results);
    }

    public function userMailing(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;

        $results = DB::selectOne('SELECT * FROM crm.spu_usermailing_dat(?,?,?,?,?,?,?);', 
            [
                $p_usr_id
                , $p_start
                , $p_end
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function userCorporativeReg(Request $request)
    {
        $p_usr_partnr = $request['p_usr_partnr'];
        $p_usr_passwd = $request['p_usr_passwd'];
        $p_udt_id = $request['p_udt_id'];
        $p_usr_docnum = $request['p_usr_docnum'];
        $p_usr_finame = $request['p_usr_finame'];
        $p_usr_laname = $request['p_usr_laname'];
        $p_uem_addres = $request['p_uem_addres'];
        $p_pfx_id = $request['p_pfx_id'];
        $p_upn_phonum = $request['p_upn_phonum'];
        $p_pck_id = $request['p_pck_id'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_usercorp_reg(?,?,?,?,?,?,?,?,?,?,?);',
            [
                $p_usr_partnr,
                $p_usr_passwd,
                $p_udt_id,
                $p_usr_docnum,
                $p_usr_finame,
                $p_usr_laname,
                $p_uem_addres,
                $p_pfx_id,
                $p_upn_phonum,
                $p_pck_id,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    public function userCorporativePackageReg(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
        $p_pck_id = $request['p_pck_id'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_usercorppackage_reg(?,?,?);',
            [
                $p_usr_id,
                $p_pck_id,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    public function userUpdate(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
	    $p_usr_partnr = $request['p_usr_partnr'];
	    $p_usr_passwd = $request['p_usr_passwd'];
	    $p_udt_id = $request['p_udt_id'];
	    $p_usr_docnum = $request['p_usr_docnum'];
	    $p_usr_niname = $request['p_usr_niname'];
	    $p_usr_finame = $request['p_usr_finame'];
	    $p_usr_laname = $request['p_usr_laname'];
	    $p_uem_addres = $request['p_uem_addres'];
	    $p_pfx_id = $request['p_pfx_id'];
	    $p_upn_phonum = $request['p_upn_phonum'];
	    $p_ucn_id = $request['p_ucn_id'];
	    $p_uwa_wallet = $request['p_uwa_wallet'];
	    $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM crm.spu_user_upd(?,?,?,?,?,?,?,?,?,?,?,?,?,?);',
            [
                $p_usr_id
                , $p_usr_partnr
                , $p_usr_passwd
                , $p_udt_id
                , $p_usr_docnum
                , $p_usr_niname
                , $p_usr_finame
                , $p_usr_laname
                , $p_uem_addres
                , $p_pfx_id
                , $p_upn_phonum
                , $p_ucn_id
                , $p_uwa_wallet
                , $p_lng_code
            ]
        );

        return $this->resultSet($results);

    }

    public function userNodeList(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 1;

        $results = DB::select('SELECT * FROM crm.spu_usernode_sel(?);'
            , [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    public function userRangeList(Request $request)
    {
        $p_date = $request['p_date'] ?: '';
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userrange_sel(?,?,?,?,?,?,?);', 
            [
                $p_date
                , $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function userRangeReport(Request $request)
    {
        $p_date = $request['p_date'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userrange_rpt(?);', 
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    public function userRangeChart(Request $request)
    {
        $p_date = $request['p_date'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_chartuserrange_sel(?);', 
            [
                $p_date
            ]
        );

        return response()->json($results);
    }

    public function userRangeUpgradeList(Request $request)
    {   
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_userrangeupd_sel(?,?,?,?,?,?,?,?);', 
            [
                $p_start
                , $p_end
                , $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function userRangeUpgradeReport(Request $request)
    {
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_userrangeupd_rpt(?,?);', 
            [
                $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function bulkPayReport(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;
        $p_start = $request['p_start'] ?: '';
        $p_end = $request['p_end'] ?: '';

        $results = DB::select('SELECT * FROM crm.spu_bulkpay_rpt(?,?,?);', 
            [
                $p_type
                , $p_start
                , $p_end
            ]
        );

        return response()->json($results);
    }

    public function userFlagExceptional(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
        
        $results = DB::select('SELECT * FROM crm.spu_userexcep_flg(?);', 
            [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    public function packageList(Request $request)
    {

        $results = DB::selectOne('SELECT * FROM crm.spu_package_sel();', []);

        return response()->json($results);
    }

    public function multimediaVideoList(Request $request)
    {
        $p_order_type = $request['p_order_type'];
        $p_order = $request['p_order'];
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];
        $results = DB::selectOne('SELECT * FROM crm.spu_package_sel(?,?,?,?);', 
            [
                $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
            ]
        );

        return response()->json($results);
    }

    public function multimediaVideoRegister(Request $request)
    {
        $p_vid_title = $request['p_vid_title'];
        $p_vid_embed = $request['p_vid_embed'];
        $results = DB::selectOne('SELECT * FROM crm.spu_package_sel(?,?);', 
            [
                $p_vid_title
                , $p_vid_embed
            ]
        );

        return response()->json($results);
    }

    public function multimediaVideoStatus(Request $request)
    {
        $p_vid_id = $request['p_vid_id'];
        $results = DB::selectOne('SELECT * FROM crm.spu_package_stt(?);', 
            [
                $p_vid_id
            ]
        );

        return response()->json($results);
    }

}