<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class PasswordRecoveryController extends Controller
{

    public function __construct()
    {
    }

    /**
     * user password recovery request register
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\Jsonresponse
     */
    public function request(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_passwordrecoveryrequest_reg(?,?);',
            [
                $p_usr_email,
                $p_lng_code
            ]
        );

        if (isset($results->error) && $results->error == 0) {
            $data = json_decode(json_encode($results), true);
            $id = ($data['id'] ?: 0);
            $data = json_decode($data['extra'], true);
            $json = json_encode(['p_code' => $data['tkn']]);
            $mail = $this->sendMail($p_lng_code, $json, 'password-recovery', $p_usr_email, $data['to'], $id);
        }

        return $this->resultSet($results);
    }

    /**
     * password recovery token validation
     * 
     * @author Josue
     * @last Josue
     * @param Request $reques
     * @return \Illuminate\Http\Jsonresponse
     */
    public function tokenValidation(Request $request)
    {
        $p_prr_token = $request['p_prr_token'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_passwordrecoveryrequest_val(?,?);',
            [
                $p_prr_token,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * password recovery change password and disable token
     * 
     * @author Josue
     * @last Josue
     * @param Request $reques
     * @return \Illuminate\Http\Jsonresponse
     */
    public function change(Request $request)
    {
        $p_prr_token = $request['p_prr_token'];
        $p_usr_passwd = $request['p_usr_passwd'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM users.spu_passwordrecoveryrequest_fin(?,?,?);',
            [
                $p_prr_token,
                $p_usr_passwd,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

}