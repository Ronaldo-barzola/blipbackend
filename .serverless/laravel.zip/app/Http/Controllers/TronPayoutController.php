<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class TronPayoutController extends Controller{
    private $tronGridApiKey = 'ddafd86e-2c05-4a42-a077-5b43b0d269f0';
    private $tronGridEnvironment = 'https://api.shasta.trongrid.io';

    public function accountInfo(Request $request){
        $client = new \GuzzleHttp\Client();
        $address = $request['address'];

        $response = $client->request('GET', $this->tronGridEnvironment.'/v1/accounts/'.$address, [
            'headers' => [
                'accept' => 'application/json',
            ],
        ]);

        return response()->json(json_decode($response->getBody()));
    }

    public function transactionInfo(Request $request){
        $client = new \GuzzleHttp\Client();
        $address = $request['address'];

        $response = $client->request('GET', $this->tronGridEnvironment.'/v1/accounts/'.$address.'/transactions', [
            'headers' => [
                'accept' => 'application/json',
            ],
        ]);

        return response()->json(json_decode($response->getBody()));
    }

    public function sendTRXPrivateKey(Request $request){
        $client = new \GuzzleHttp\Client();

        $privateKey = $request['privateKey'];
        $ownAddress = $request['ownAddress'];
        $toAddress = $request['toAddress'];
        $amount = $request['amount'] * 1000000;

        

        $data = [
            'contract_address' => 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
            'function_selector' => 'transfer(address,uint256)',
            'parameter' => $parameter,
            'fee_limit' => 100000000,
            'call_value' => 0,
            'owner_address' => '"'.$ownAddress.'"',
            'private_key' => '"'.$privateKey.'"',
            'visible' => true,
        ];
        
        

        $response = $client->request('POST', $this->tronGridEnvironment.'/wallet/triggersmartcontract', [
            'body' => json_encode($data),
            'headers' => [
                'content-type' => 'application/json',
                'TRON-PRO-API-KEY' => $this->tronGridApiKey,
            ],
        ]);

        return response()->json(json_decode($response->getBody()));
    }
}
