<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class PaymentGatewayController extends Controller
{

    // Triple A Integration
    public function get3AToken()
    {
        $client_id = "oacid-cldylmhk10mai1nis1otoea99";
        $client_secret = "c3804fe1374b6b675e24ebf0de2a9571bd5fc20d5f5b2d0aeab6e237c0be3d13";
        $merchant_key = "mkey-cldylmhjv0mah1nis1ofh00j4";
        $grant_type = "client_credentials";

        $curl = curl_init();

        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => 'https://api.triple-a.io/api/v2/oauth/token',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => 'client_id=' . $client_id . '&client_secret=' . $client_secret . '&grant_type=' . $grant_type . "&usdt_api_id=USDT1675801302bcyw2P8m",
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/x-www-form-urlencoded'
                ),
            )
        );

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            $json_response = json_decode($response);
            return response()->json($json_response);
        }
    }

    public function statusPayment(Request $request)
    {
        $token = $request['token'];
        $payment_reference = $request['payment_reference'];

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.triple-a.io/api/v2/payment/" . $payment_reference,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer " . $token,
                "Content-Type: application/json"
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            $json_repsonse = json_decode($response);
            return response()->json($json_repsonse);
        }

    }

    public function getEmbedPaymentForm(Request $request)
    {
        $client_id = "oacid-cldylmhk10mai1nis1otoea99";
        $client_secret = "c3804fe1374b6b675e24ebf0de2a9571bd5fc20d5f5b2d0aeab6e237c0be3d13";
        $merchant_key = "mkey-cldylmhjv0mah1nis1ofh00j4";
        $grant_type = "client_credentials";

        $amount = $request['amount'];
        $payer_id = $request['payer_id'];
        $token = $request['token'];
        $curl = curl_init();

        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => 'https://api.triple-a.io/api/v2/payment',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => '{
                    "type": "widget",
                    "merchant_key": "' . $merchant_key . '",
                    "order_currency": "USD",
                    "order_amount": ' . $amount . ',
                    "payer_id": "' . $payer_id . '",
                    "sandbox": true
                }',
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer ' . $token,
                    'Content-Type: application/json'
                ),
            )
        );

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            $json_response = json_decode($response);
            return response()->json($json_response);
        }
    }

    public function sendBulkPayment(Request $request)
    {
        $client_id = "oacid-cldylmhk10mai1nis1otoea99";
        $client_secret = "c3804fe1374b6b675e24ebf0de2a9571bd5fc20d5f5b2d0aeab6e237c0be3d13";
        $merchant_key = "mkey-cldylmhjv0mah1nis1ofh00j4";
        $grant_type = "client_credentials";

        $amount = $request['amount'];
        $payer_id = $request['payer_id'];
        $client_wallet = $request['client_wallet'];
        $token = $request['token'];

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.triple-a.io/api/v2/payout/withdraw/local/crypto/direct",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => '{
                "merchant_key": "' . $merchant_key . '",
                "email": "' . $payer_id . '",
                "withdraw_currency": "USD",
                "withdraw_amount": "' . $amount . '",
                "crypto_currency": "testBTC",
                "remarks": "A Testing App Bonus Payout",
                "address": "' . $client_wallet . '",
                "name": "Testing App",
                "country": "MX"}',
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json'
            ],
        ]);

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            $json_response = json_decode($response);
            return response()->json($json_response);
        }
    }


    public function logsBb(Request $request)
    {

        $ticker = "trx";
        $query = array(
            "apikey" => "PnvUdEVndx4mEs7oxFdkLP9pQpihAJ9z2FmF0GTLJ5ZR7hbouqIhXb2MetFzvbFV",
            "callback" => "example.com/invoice/1234?payment_id=5678"
        );
        // print_r($query);
        // die();

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.blockbee.io/" . $ticker . "/logs/?" . http_build_query($query),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ]);


        $respuesta = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            echo $respuesta;
        }
    }





    // BlockBee Integration


    public function bbGetInvestmentForm(Request $request)
    {


        $query = array(
            "apikey" => "string",
            "notify_url" => "string",
            "item_description" => "string",
            "post" => "0"
        );

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.blockbee.io/deposit/request/?" . http_build_query($query),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ]);

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            echo $response;
        }

    }

    public function bbGetEmbedPaymentForm(Request $request)
    {
        $amount = $request['amount'];
        $descri = $request['descri'];
        $wpy_id = $request['wpy_id'];
        $flg_tp = $request['flg_tp'];
        $apikey = '';

        if ($flg_tp == 1) {
            // Paquetes
            $apikey = "oAPX74wdBl2SCmfbjDzyy3FPocNzdLNKFJC86NUFyjNXJg8WkSzN52txXmgT6Qz7";
        } else {
            // Inversión
            $apikey = "PnvUdEVndx4mEs7oxFdkLP9pQpihAJ9z2FmF0GTLJ5ZR7hbouqIhXb2MetFzvbFV";
        }

        $query = array(
            "apikey" => $apikey,
            "redirect_url" => "https://web.kaizenapp.io",
            "value" => $amount,
            "item_description" => '"' . $descri . '"',
            "notify_url" => "https://valkyria.kaizenapp.io/v1/payment-gateway/bb/update-status-payment/?wpy_id=" . $wpy_id,
            "post" => "0"
        );

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.blockbee.io/checkout/request/?" . http_build_query($query),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ]);

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            $json_response = json_decode($response);
            return response()->json($json_response);
        }
    }

    public function bbUpdateStatusPayment(Request $request)
    {
        // $arr_received_info = array();

        $data['wpy_id'] = $request['wpy_id'];
        $data['payment_url'] = $request['payment_url'];
        $data['redirect_url'] = $request['redirect_url'];
        $data['value'] = $request['value'];
        $data['success_token'] = $request['success_token'];
        $data['currency'] = $request['currency'];
        $data['is_paid'] = $request['is_paid'];
        $data['paid_amount'] = $request['paid_amount'];
        $data['paid_coin'] = $request['paid_coin'];
        $data['exchange_rate'] = $request['exchange_rate'];
        $data['tx_id'] = $request['txid'];
        $data['wallet'] = $request['address'];
        $data['status'] = $request['status'];
        $data['p_lng_code'] = 'en';

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpayment_set(?,?,?);',
            [
                $request['wpy_id'],
                $request['address'],
                'en'
            ]
        );

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpayment_cnf(?,?,?);',
            [
                $request['address'],
                json_encode($data),
                'en'
            ]
        );

        return 'ok';
    }

    public function bbEstimatedGas(Request $request)
    {
        $ticker = "trc20/usdt";

        $query = array(
            "apikey" => "oAPX74wdBl2SCmfbjDzyy3FPocNzdLNKFJC86NUFyjNXJg8WkSzN52txXmgT6Qz7",
            "addresses" => 1,
            "priority" => "default"
        );

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.blockbee.io/" . $ticker . "/estimate/?" . http_build_query($query),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ]);

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            $json_response = json_decode($response);
            return response()->json($json_response);
        }
    }

    public function apiBase(Request $request)
    {
        $ticker = "trc20/usdt";
        $flg_tp = $request['flg_tp'];
        $wpy_id = $request['wpy_id'];
        $apikey = '';

        if ($flg_tp == 1) {
            // Paquetes
            $apikey = "oAPX74wdBl2SCmfbjDzyy3FPocNzdLNKFJC86NUFyjNXJg8WkSzN52txXmgT6Qz7";
        } else {
            // Inversión
            $apikey = "PnvUdEVndx4mEs7oxFdkLP9pQpihAJ9z2FmF0GTLJ5ZR7hbouqIhXb2MetFzvbFV";
        }

        $query = array(
            "apikey" => $apikey,
            "callback" => "https://valkyria.kaizenapp.io/v1/payment-gateway/bb/api-base/update/?wpy_id=" . $wpy_id,
            "address" => "",
            "pending" => "0",
            "confirmations" => "1",
            "post" => "0",
            "priority" => "",
            "multi_token" => "1",
            "multi_chain" => "0",
            "convert" => "0"
        );

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.blockbee.io/" . $ticker . "/create/?" . http_build_query($query),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ]);

        $response = curl_exec($curl);
        $error = curl_error($curl);

        curl_close($curl);

        if ($error) {
            echo "cURL Error #:" . $error;
        } else {
            $json_response = json_decode($response);
            // return $json_response->address_in;
            $results = DB::selectOne(
                'SELECT * FROM core.spu_walletpayment_set(?,?,?);',
                [
                    $wpy_id,
                    $json_response->address_in,
                    'en'
                ]
            );


            return response()->json($json_response);
        }

    }

    public function walletPaymentDepositSel(Request $request)
    {
        $p_wpy_id = $request['p_wpy_id'];
        $p_offset = $request['p_offset'];
        $p_limit = $request['p_limit'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::select(
            'SELECT * FROM core.spu_walletpaymentdeposit_sel(?,?,?,?);',
            [
                $p_wpy_id,
                $p_offset,
                $p_limit,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function apiBaseUpdate(Request $request)
    {
        $data['p_wpy_waladd'] = $request['address_in'];
        $data['p_wpd_uuid'] = $request['uuid'];
        $data['p_wpd_addin'] = $request['address_in'];
        $data['p_wpd_amount'] = $request['value_forwarded_coin'];
        $data['p_wpd_hash'] = $request['txid_in'];
        $data['p_wpd_addout'] = $request['address_out'];
        $data['p_wpd_coin'] = $request['coin'];
        $data['p_lng_code'] = 'en';
        $data['p_wpy_id']= $request['wpy_id'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpaymentdeposit_reg(?,?,?,?,?,?,?,?,?);',
            [
                $data['p_wpy_id'],
                $data['p_wpy_waladd'],
                $data['p_wpd_uuid'],
                $data['p_wpd_addin'],
                $data['p_wpd_amount'],
                $data['p_wpd_hash'],
                $data['p_wpd_addout'],
                $data['p_wpd_coin'],
                'en'
            ]
        );
        // return response()->json($results);
        return 'ok';
    }



}