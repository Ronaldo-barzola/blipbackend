<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class CryptoStatusController extends Controller
{

    public function __construct()
    {

    }

    public function cryptoReg(Request $request)
    {
        try {
            $crypto_coin = $request['crypto_coin'];
            $type = strtoupper($request['type']) == 'VENTA' ? 0 : 1;
            $opening_date = $request['opening_date'];
            $opening_price = $request['opening_price'] ?: '0';
            $closing_date = $request['closing_date'];
            $closing_price = $request['closing_price'] ?: '0';
            $price_change = str_replace('%', '', ($request['price_change'] ?: '0'));
            $profit = str_replace('%', '', ($request['profit'] ?: '0'));
    
            $results = DB::selectOne('SELECT * FROM core.spu_cryptostatus_reg(?,?,?,?,?,?,?,?);', [
                $crypto_coin
                , $type
                , $opening_date
                , $opening_price
                , $closing_date
                , $closing_price
                , $price_change
                , $profit
            ]);

            $this->resultSet($results);

            return response()->json($results);
        } catch (Exception $e) {
            return response()->json(['error' => 500, 'message' => '']);
        }

        
    }

}