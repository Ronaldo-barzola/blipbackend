<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class WithdrawController extends Controller
{

    public function __construct()
    {

    }

    /**
     * get income for withdraw
     * 
     * @author Josue
     * @last Josue
     */
    public function available(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::selectOne('SELECT * FROM core.spu_userpackagedetailwithdrawavailable_sel(?);', [$p_usr_email]);

        return response()->json($results);
    }

    /**
     * generate validation token
     * 
     * @author Josue
     * @last Josue
     */
    public function generateToken(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM core.spu_withdrawrequesttoken_reg(?,?)',
            [
                $p_usr_email,
                $p_lng_code
            ]
        );

        $data = json_decode(json_encode($results), true);
        if ($data) {
            $resultsU = DB::selectOne('SELECT * FROM users.spu_user_src(?);', [ $p_usr_email]);
            $user = [];
            if ($resultsU) {
                $user = json_decode(json_encode($resultsU), true);
                // $this->sendSMS($user['pfx_number'], $user['upn_phonum'], 'KAIZEN WITHDRAW CODE: ' . $data['extra']);
            }
        }

        return $this->resultSet($results);
    }

    /**
     * generate validation token
     * 
     * @author Josue
     * @last Josue
     */
    public function validateToken(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_wrt_mailtk = $request['p_wrt_mailtk'];
        $p_wrt_smstkn = $request['p_wrt_smstkn'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM core.spu_withdrawrequesttoken_val(?,?,?,?)',
            [
                $p_usr_email,
                $p_wrt_mailtk,
                $p_wrt_smstkn,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * resend validation token
     * 
     * @author Josue
     * @last Josue
     */
    public function resendToken(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_wtr_flag = $request['p_wtr_flag'] ?: 1;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM core.spu_withdrawrequesttoken_res(?,?,?)',
            [
                $p_usr_email,
                $p_wtr_flag,
                $p_lng_code
            ]
        );

        $data = json_decode(json_encode($results), true);
        if ($data) {
            $resultsU = DB::selectOne('SELECT * FROM users.spu_user_src(?);', [ $p_usr_email]);
            $user = [];
            if ($resultsU) {
                $user = json_decode(json_encode($resultsU), true);
                if ($p_wtr_flag == 1) {
                    $this->sendSMS($user['pfx_number'], $user['upn_phonum'], 'KAIZEN WITHDRAW CODE: ' . $data['extra']);
                }
            }
        }

        return $this->resultSet($results);
    }
    
    /**
     * register request
     * 
     * @author Josue
     * @last Josue
     */
    public function registerRequest(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_wdr_amount = $request['p_wdr_amount'];
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne(
            'SELECT * FROM core.spu_withdrawrequest_reg(?,?,?)',
            [
                $p_usr_email,
                $p_wdr_amount,
                $p_lng_code
            ]
        );

        return $this->resultSet($results);
    }

    /**
     * get withdraw requests history
     * 
     * @author Josue
     * @last Josue
     */
    public function history(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_withdrawrequest_sel(?,?,?,?);', 
            [
                $p_usr_email
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function dateVal(Request $request)
    {
        $results = DB::selectOne('SELECT * FROM core.spu_withdrawprogramdate_sel()',
            []
        );
        return response()->json($results);
    }

}