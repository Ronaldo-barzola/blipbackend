<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class MasterController extends Controller
{

    public function __construct()
    {
    }

    /**
     * list countries
     * @author Josue
     * @last Josue
     */
    public function countryList(Request $request) {
        $results = DB::select('SELECT * FROM master.spu_country_sel();');

        return response()->json($results);
    }

    /**
     * list document types
     * @author Josue
     * @last Josue
     */
    public function documentTypeList(Request $request) {
        $results = DB::select('SELECT * FROM master.spu_userdocumenttype_sel();');

        return response()->json($results);
    }

    /**
     * list sign in receive code method
     * @author Josue
     * @last Josue
     */
    public function signInMethodList(Request $request) {
        $p_usr_email = $request['p_usr_email'] ?: '';
        $results = DB::select('SELECT * FROM master.spu_signincodemethod_sel(?);',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    /**
     * list crypto coin nets
     * @author Josue
     * @last Josue
     */
    public function coinNetList(Request $request) {
        $results = DB::select('SELECT * FROM users.spu_usercoinnet_sel();', []);

        return response()->json($results);
    }

}