<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class WalletController extends Controller
{

    public function __construct()
    {
    }

    /**
     * get created payment wallet by id
     * @author Josue
     * @last Josue
     */
    public function search(Request $request) {
        $p_wpy_id = $request['p_wpy_id'];

        $results = DB::selectOne('SELECT * FROM core.spu_walletpayment_src(?);', [$p_wpy_id]);

        return response()->json($results);
    }

    /**
     * create swagger wallet
     * @author Josue
     * @last Josue
     */
    public function walletCreate(Request $request) {
        $url = 'https://45.155.120.204/api/token/create';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $result = curl_exec($ch);
        // echo response()->json($result);
        print_r($result);
        // print_r($result);
    }

    /**
     * 
     */
    public function tmpApprove(Request $request) {
        $p_wpy_waladd = $request['p_wpy_waladd'];
        $p_lng_code = 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_walletpayment_cnf(?,?);', [$p_wpy_waladd, $p_lng_code]);

        return response()->json($results);
    }

    /**
     * 
     */
    public function tmpDeppot(Request $request) {
        $p_wpy_waladd = $request['p_wpy_waladd'];
        $p_wpd_amount = $request['p_wpd_amount'];
        $p_wpd_hash = self::generateRandomString(20);
        $p_lng_code = 'en';

        $results = DB::selectOne('SELECT * FROM core.spu_walletpaymentdeposit_reg(?,?,?,?);'
            , [
                $p_wpy_waladd
                , $p_wpd_amount
                , $p_wpd_hash
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

}