<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\UserCRM;
use App\Http\Controllers\PaymentGatewayController;

class CrmAdminController extends Controller
{

    public function __construct()
    {
    }

    public function crmUserSearch(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_usr_niname = $request['p_usr_niname'] ?: '';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmuser_src(?,?);', 
            [
                $p_usr_id
                , $p_usr_niname
            ]
        );

        return response()->json($results);
    }

    public function crmUpdatePropic(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_usr_propic = $request['p_usr_propic'] ?: '';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmuserpropic_upd(?,?);', 
            [
                $p_usr_id
                , $p_usr_propic
            ]
        );

        return response()->json($results);
    }

    public function crmUpdatePassword(Request $request)
    {
        $p_usr_id = $request['p_usr_id'] ?: 0;
        $p_usr_passwd = $request['p_usr_passwd'] ?: '';
        $p_usr_newpss = $request['p_usr_newpss'] ?: '';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmuserpassword_upd(?,?,?);', 
            [
                $p_usr_id
                , $p_usr_passwd
                , $p_usr_newpss
            ]
        );

        return response()->json($results);
    }

    public function crmUserList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmuser_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function crmProfileSelect(Request $request)
    {
        $results = DB::selectOne('SELECT * FROM crm.spu_crmprofileselect_sel();', []
        );

        return response()->json($results);
    }

    public function crmUserRegister(Request $request)
    {
        $p_usr_name = $request['p_usr_name'];
        $p_prf_id = $request['p_prf_id'];
        $p_usr_passwd = $request['p_usr_passwd'];
        $p_usr_charge = $request['p_usr_charge'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmuser_reg(?,?,?,?);'
            , [
                $p_usr_name
                , $p_prf_id
                , $p_usr_passwd
                , $p_usr_charge
            ]
        );

        return response()->json($results);
    }

    public function crmUserUpdate(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
        $p_usr_name = $request['p_usr_name'];
        $p_prf_id = $request['p_prf_id'];
        $p_usr_charge = $request['p_usr_charge'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmuser_upd(?,?,?,?);'
            , [
                $p_usr_id
                , $p_usr_name
                , $p_prf_id
                , $p_usr_charge
            ]
        );

        return response()->json($results);
    }

    public function crmUserStatus(Request $request)
    {
        $p_usr_id = $request['p_usr_id'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmuser_stt(?);'
            , [
                $p_usr_id
            ]
        );

        return response()->json($results);
    }

    public function crmProfileList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmprofile_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function crmProfileRegister(Request $request)
    {
        $p_prf_name = $request['p_prf_name'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmprofile_reg(?);'
            , [
                $p_prf_name
            ]
        );

        return response()->json($results);
    }

    public function crmProfileUpdate(Request $request)
    {
        $p_prf_id = $request['p_prf_id'];
        $p_prf_name = $request['p_prf_name'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmprofile_upd(?,?);'
            , [
                $p_prf_id
                , $p_prf_name
            ]
        );

        return response()->json($results);
    }

    public function crmProfileMenuList(Request $request)
    {
        $p_prf_id = $request['p_prf_id'];
        $results = DB::select('SELECT * FROM crm.spu_crmprofilemenu_sel(?);'
            , [
                $p_prf_id
            ]
        );

        return response()->json($results);
    }

    public function crmProfileMenuStatus(Request $request)
    {
        $p_prf_id = $request['p_prf_id'];
        $p_men_id = $request['p_men_id'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmprofilemenu_stt(?,?);'
            , [
                $p_prf_id
                , $p_men_id
            ]
        );

        return response()->json($results);
    }

    public function crmProfilePageList(Request $request)
    {
        $p_prf_id = $request['p_prf_id'];
        $results = DB::select('SELECT * FROM crm.spu_crmprofilepage_sel(?);'
            , [
                $p_prf_id
            ]
        );

        return response()->json($results);
    }

    public function crmProfilePageStatus(Request $request)
    {
        $p_prf_id = $request['p_prf_id'];
        $p_pag_id = $request['p_pag_id'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmprofilepage_stt(?,?);'
            , [
                $p_prf_id
                , $p_pag_id
            ]
        );

        return response()->json($results);
    }

    public function crmMenuList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmmenu_dat(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function crmMenuRegister(Request $request)
    {
        $p_men_name = $request['p_men_name'];
        $p_men_url = $request['p_men_url'];
        $p_men_icon = $request['p_men_icon'];
        $p_men_order = $request['p_men_order'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmmenu_reg(?,?,?,?);'
            , [
                $p_men_name
                , $p_men_url
                , $p_men_icon
                , $p_men_order
            ]
        );

        return response()->json($results);
    }

    public function crmMenuUpdate(Request $request)
    {
        $p_men_id = $request['p_men_id'];
        $p_men_name = $request['p_men_name'];
        $p_men_url = $request['p_men_url'];
        $p_men_icon = $request['p_men_icon'];
        $p_men_order = $request['p_men_order'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmmenu_upd(?,?,?,?,?);'
            , [
                $p_men_id
                , $p_men_name
                , $p_men_url
                , $p_men_icon
                , $p_men_order
            ]
        );

        return response()->json($results);
    }

    public function crmMenuStatus(Request $request)
    {
        $p_men_id = $request['p_men_id'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmmenu_stt(?);'
            , [
                $p_men_id
            ]
        );

        return response()->json($results);
    }

    public function crmPageList(Request $request)
    {
        $p_search = $request['p_search'] ?: '';
        $p_order_type = $request['p_order_type'] ?: 1;
        $p_order = $request['p_order'] ?: 1;
        $p_offset = $request['p_offset'] ?: 0;
        $p_limit = $request['p_limit'] ?: 10;
        $p_lng_code = $request['p_lng_code'] ?: 'en';

        $results = DB::selectOne('SELECT * FROM crm.spu_crmpage_sel(?,?,?,?,?,?);', 
            [
                $p_search
                , $p_order_type
                , $p_order
                , $p_offset
                , $p_limit
                , $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function crmPageRegister(Request $request)
    {
        $p_pag_descri = $request['p_pag_descri'];
        $p_pag_url = $request['p_pag_url'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmpage_reg(?,?);'
            , [
                $p_pag_descri
                , $p_pag_url
            ]
        );

        return response()->json($results);
    }

    public function crmPageUpdate(Request $request)
    {
        $p_pag_id = $request['p_pag_id'];
        $p_pag_descri = $request['p_pag_descri'];
        $p_pag_url = $request['p_pag_url'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmpage_upd(?,?,?);'
            , [
                $p_pag_id
                , $p_pag_descri
                , $p_pag_url
            ]
        );

        return response()->json($results);
    }

    public function crmPageStatus(Request $request)
    {
        $p_pag_id = $request['p_pag_id'];
        $results = DB::selectOne('SELECT * FROM crm.spu_crmpage_stt(?);'
            , [
                $p_pag_id
            ]
        );

        return response()->json($results);
    }

    public function paramList(Request $request)
    {
        $p_type = $request['p_type'] ?: 1;

        $results = DB::select('SELECT * FROM variable.spu_param_sel(?);'
            , [
                $p_type
            ]
        );

        return response()->json($results);
    }

    public function paramEdit(Request $request)
    {
        $p_prm_id = $request['p_prm_id'];
        $p_prm_value = $request['p_prm_value'];
        $p_prm_extra = $request['p_prm_extra'];

        $results = DB::selectOne('SELECT * FROM variable.spu_param_upd(?,?,?);'
            , [
                $p_prm_id
                , $p_prm_value
                , $p_prm_extra
            ]
        );

        return response()->json($results);
    }

}