<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class CountryController extends BaseController
{

    public function __construct()
    {
    }

    /**
     * list countries and phone prefix
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sel(Request $request)
    {

        $results = DB::select(
            'SELECT * FROM master.spu_country_sel();'
        );

        return response()->json($results);
    }

}