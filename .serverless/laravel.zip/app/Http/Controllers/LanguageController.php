<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class LanguageController extends BaseController
{

    public function __construct()
    {

    }

    /**
     * get default language code
     * @author Josue
     * @last Josue
     */
    public function default(Request $request)
    {
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM language.spu_language_dfl(?);'
            , [
                $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function languageSel(Request $request)
    {
        $p_lng_code = $request['p_lng_code'];
        $p_lng_active = $request['p_lng_active'];

        $results = DB::select('SELECT * FROM language.spu_language_sel(?,?);', [$p_lng_code, $p_lng_active]);
        return response()->json($results);
    }

    /**
     * language variables sel
     * 
     * @author Josue
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function variables(Request $request)
    {
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne('SELECT * FROM variable.spu_variable_sel(?);', [$p_lng_code]);

        return response()->json($results);
    }

    /**
     * language list
     * 
     * @author Ronaldo
     * @last Josue
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function list(Request $request)
    {
        $p_lng_code = $request['p_lng_code'] ?: '';
        $p_lng_active = $request['p_lng_active'] ?: true;

        $results = DB::select(
            'SELECT * FROM language.spu_language_sel(?,?);',
            [
                $p_lng_code,
                $p_lng_active
            ]
        );

        return response()->json($results);
    }



}