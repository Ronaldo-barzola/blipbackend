<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Illuminate\Support\Facades\DB;

use App\Http\Controllers\SendMailController;

class MailController extends Controller
{



  // function mailSel($p_mat_jso = '{}', $p_mat_name = '', $p_lng_code = '')
  // {
  //   $p_mat_jso = $p_mat_jso;
  //   $p_mat_name = $p_mat_name;
  //   $p_lng_code = $p_lng_code;

  //   $results = DB::selectOne('SELECT * FROM mail.spu_maillanguage_get(?,?,?);', [$p_mat_jso, $p_mat_name, $p_lng_code]);

  //   return $results;
  // }

  // public static function sendMail($p_lng_code, $params, $p_mat_name, $p_to_mail, $p_to_name)
  // {
  //   // $p_mat_jso = json_encode(["p_code" => $request['p_code']]);
  //   $mail = self::mailSel($params, $p_mat_name, $p_lng_code);

  //   $p_to_mail = $p_to_mail;
  //   $p_to_name = $p_to_name;


  //   $html = $mail->extra;
  //   $subject = $mail->extra2;

  //   $mailParams = DB::selectOne('SELECT * FROM variable.spu_parammail_sel();', []);
  //   if ($mailParams) {
  //     $mailParams = json_decode(json_encode($mailParams), true);
  //     $mail = new PHPMailer(true);
  //     try {
  //       $mail->SMTPDebug = 1;
  //       $mail->CharSet = 'UTF-8';
  //       $mail->isSMTP();
  //       $mail->Host = $mailParams['mail-host'];
  //       $mail->SMTPAuth = true;
  //       $mail->Username = $mailParams['mail-username'];
  //       $mail->Password = $mailParams['mail-password'];
  //       $mail->SMTPSecure = 'ssl';
  //       $mail->Port = 465;
  //       $mail->setFrom('noreply@mailing.kaizenapp.io', $mailParams['mail-from']);
  //       $mail->addAddress($p_to_mail, $p_to_name);
  //       $mail->addReplyTo('noreply@mailing.kaizenapp.io', $mailParams['mail-from']);

  //       $mail->Subject = $subject;

  //       $mail->Body = $html;
  //       $mail->isHTML(true);

  //       $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
  //       $mail->SMTPOptions = array(
  //         'ssl' => array(
  //           'verify_peer' => false,
  //           'verify_peer_name' => false,
  //           'allow_self_signed' => true
  //         )
  //       );
  //       $mail->send();

  //       return $mail->ErrorInfo;
  //     } catch (Exception $e) {
  //       echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  //       return false;

  //     }
  //   }
    
  // }

  // public function sendMail(Request $request)
  // {
  //   $p_mat_jso = json_encode(["p_code" => $request['p_code']]);
  //   $p_mat_name = $request['p_mat_name'];
  //   $p_lng_code = $request['p_lng_code'];
  //   $data = self::mailSel($p_mat_jso, $p_mat_name, $p_lng_code);

  //   $p_to_mail = $request['p_to_mail'];
  //   $p_to_name = $request['p_to_name'];
  //   $p_subject = $request['p_subjetc'];


  //   $html = $data[0]->extra;

  //   $mail = new PHPMailer(true);
  //   try {
  //     $mail->SMTPDebug = 1;
  //     $mail->CharSet = 'UTF-8';
  //     $mail->isSMTP();
  //     $mail->Host = 'smtp.mailgun.org';
  //     $mail->SMTPAuth = true;
  //     $mail->Username = 'noreply@mailing.kaizenapp.io';
  //     $mail->Password = '22d14194d9be9d791429df5862d5b4b7-75cd784d-57696475';
  //     $mail->SMTPSecure = 'ssl';
  //     $mail->Port = 465;
  //     $mail->setFrom('noreply@mailing.kaizenapp.io', 'Kaizen');
  //     $mail->addAddress($p_to_mail, $p_to_name);
  //     $mail->addReplyTo('noreply@mailing.kaizenapp.io', 'Kaizen');

  //     $mail->Subject = $p_subject;

  //     $mail->Body = $html;
  //     $mail->isHTML(true);

  //     $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
  //     $mail->SMTPOptions = array(
  //       'ssl' => array(
  //         'verify_peer' => false,
  //         'verify_peer_name' => false,
  //         'allow_self_signed' => true
  //       )
  //     );
  //     $mail->send();

  //     return $mail->ErrorInfo;
  //   } catch (Exception $e) {
  //     echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  //     return false;

  //   }
  // }
}