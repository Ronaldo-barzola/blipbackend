<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class PurchaseController extends Controller
{

    public function __construct()
    {

    }

    /**
     * start purchase generate wallet
     * 
     * @author Josue
     * @last Josue
     */

    public function paymentCnf(Request $request)
    {
        $p_wpy_waladd = $request['p_wpy_waladd'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpayment_cnf(?,?);',
            [
                $p_wpy_waladd
                ,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function paymentExpired(Request $request)
    {
        $p_wpy_waladd = $request['p_wpy_waladd'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpayment_exp(?,?);',
            [
                $p_wpy_waladd
                ,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function paymentForm(Request $request)
    {
        $p_wpy_id = $request['p_wpy_id'];
        $p_form = $request['p_form'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpaymentform_set(?,?,?);',
            [
                $p_wpy_id,
                $p_form,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }


    public function updateWallet(Request $request)
    {
        $p_wpy_id = $request['p_wpy_id'];
        $p_wpy_waladd = $request['p_wpy_waladd'];
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_walletpayment_set(?,?,?);',
            [
                $p_wpy_id
                ,
                $p_wpy_waladd
                ,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }
    public function start(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_ucn_id = $request['p_ucn_id'];
        $p_pck_id = $request['p_pck_id'];
        $p_lng_code = $request['p_lng_code'];
        $p_wpy_waladd = self::generateRandomString(20);

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userpurchase_prc(?,?,?,?,?);',
            [
                $p_usr_email
                ,
                $p_pck_id
                ,
                $p_ucn_id
                ,
                $p_wpy_waladd
                ,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }

    public function upgrade(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];
        $p_pck_id = $request['p_pck_id'];
        $p_ucn_id = $request['p_ucn_id'];
        $p_wpy_waladd = self::generateRandomString(20);
        $p_lng_code = $request['p_lng_code'];

        $results = DB::selectOne(
            'SELECT * FROM core.spu_userpackagedetail_upg(?,?,?,?,?);',
            [
                $p_usr_email,
                $p_pck_id,
                $p_ucn_id,
                $p_wpy_waladd,
                $p_lng_code
            ]
        );

        return response()->json($results);
    }


    function generateRandomString($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    function packagesPurchase(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::select(
            'SELECT * FROM core.spu_package_prc(?);',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

    function packagesUpgrade(Request $request)
    {
        $p_usr_email = $request['p_usr_email'];

        $results = DB::select(
            'SELECT * FROM core.spu_package_upg(?);',
            [
                $p_usr_email
            ]
        );

        return response()->json($results);
    }

 


}