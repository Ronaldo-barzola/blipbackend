<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return 'API REST - KAIZEN V1';
});

// Route::get('/info', function () {
//     phpinfo();
// });

Route::post('/register', 'JwtController@register');
Route::post('/login', 'JwtController@authenticate');

Route::prefix('assets')->group(
    function () {
        Route::get('mail/{sub}/{file}', 'AssetsController@mail');
    }
);

Route::post('mail-params', 'UserController@signUpMail');
Route::post('smstest', 'SmsController@send');
Route::post('crypto-bot-status', 'CryptoStatusController@cryptoReg');

Route::post('mail-trading', 'UserController@sendTrading');   

Route::prefix('v1')->group(function () {

    Route::post('validate-tron-wallet', 'BishamontenTronTools@validateWallet');

    Route::prefix('crm')->group(
        function () {
            Route::post('/sign-in', 'CrmController@signIn');
            Route::post('/external-set-bulk-pay', 'CrmController@bulkSetPay');
        }
    );

    Route::prefix('bybit')->group(
        function() {
            Route::post('account-list', 'ByBitController@accountList');
        }
    );

    Route::group(
        ['middleware' => ['jwt.verify']],
        function () {
            Route::post('token-validate', 'JwtController@tokenValidation');

            Route::prefix('crm')->group(
                function () {
                    Route::prefix('admin')->group(
                        function () {
                            Route::post('user-search', 'CrmAdminController@crmUserSearch');
                            Route::post('user-update-propic', 'CrmAdminController@crmUpdatePropic');
                            Route::post('user-update-password', 'CrmAdminController@crmUpdatePassword');
                            Route::post('user-list', 'CrmAdminController@crmUserList');
                            Route::post('profile-select', 'CrmAdminController@crmProfileSelect');
                            Route::post('user-register', 'CrmAdminController@crmUserRegister');
                            Route::post('user-update', 'CrmAdminController@crmUserUpdate');
                            Route::post('user-status', 'CrmAdminController@crmUserStatus');
                            Route::post('profile-list', 'CrmAdminController@crmProfileList');
                            Route::post('profile-register', 'CrmAdminController@crmProfileRegister');
                            Route::post('profile-update', 'CrmAdminController@crmProfileUpdate');
                            Route::post('profile-menu-list', 'CrmAdminController@crmProfileMenuList');
                            Route::post('profile-menu-status', 'CrmAdminController@crmProfileMenuStatus');
                            Route::post('profile-page-list', 'CrmAdminController@crmProfilePageList');
                            Route::post('profile-page-status', 'CrmAdminController@crmProfilePageStatus');
                            Route::post('menu-list', 'CrmAdminController@crmMenuList');
                            Route::post('menu-register', 'CrmAdminController@crmMenuRegister');
                            Route::post('menu-update', 'CrmAdminController@crmMenuUpdate');
                            Route::post('menu-status', 'CrmAdminController@crmMenuStatus');
                            Route::post('page-list', 'CrmAdminController@crmPageList');
                            Route::post('page-register', 'CrmAdminController@crmPageRegister');
                            Route::post('page-update', 'CrmAdminController@crmPageUpdate');
                            Route::post('page-status', 'CrmAdminController@crmPageStatus');
                            Route::post('param-list', 'CrmAdminController@paramList');
                            Route::post('param-edit', 'CrmAdminController@paramEdit');
                        }
                    );

                    Route::prefix('mailing')->group(
                        function () {
                            Route::post('element-list', 'CrmMailingController@elementList');
                            Route::post('image-list', 'CrmMailingController@imageList');
                            Route::post('send-test', 'CrmMailingController@sendTest');
                            Route::post('send-custom', 'CrmMailingController@sendCustom');
                            Route::post('mail-sent-list', 'CrmMailingController@mailSentList');
                            Route::post('mail-bulk-list', 'CrmMailingController@mailBulkList');
                            Route::post('mail-bulk-search', 'CrmMailingController@mailBulkSearch');
                            Route::post('mail-query-criteria-list', 'CrmMailingController@mailQueryCriteriaList');
                            Route::post('mail-query-criteria-execute', 'CrmMailingController@mailQueryCriteriaExecute');
                            Route::post('mail-bulk-register', 'CrmMailingController@mailBulkRegister');
                            Route::post('send-custom-bulk', 'CrmMailingController@sendCustomBulk');
                            Route::post('mail-bulk-finish', 'CrmMailingController@mailBulkFinish');
                        }
                    );

                    Route::post('crm-notifications', 'CrmController@crmNotifications');
                    Route::post('panel-trading-daily-list', 'CrmController@panelTradingDailyList');
                    Route::post('panel-trading-daily-report', 'CrmController@panelTradingDailyReport');
                    Route::post('panel-trading-daily-chart', 'CrmController@panelTradingDailyChart');
                    Route::post('panel-crypto-status-chart', 'CrmController@panelCryptoStatusChart');
                    Route::post('panel-mother-account-bonus-list', 'CrmController@panelMotherAccountBonusList');
                    Route::post('panel-mother-account-bonus-chart', 'CrmController@panelMotherAccountBonusChart');
                    Route::post('panel-mother-account-bonus-report', 'CrmController@panelMotherAccountBonusReport');
                    Route::post('panel-deposit-day-list', 'CrmController@panelDepositDayList');
                    Route::post('panel-deposit-day-chart', 'CrmController@panelDepositDayChart');
                    Route::post('panel-deposit-month-chart', 'CrmController@panelDepositMonthChart');
                    Route::post('panel-deposit-day-report', 'CrmController@panelDepositDayReport');
                    Route::post('panel-user-comission-list', 'CrmController@panelUserComissionList');
                    Route::post('panel-user-comission-chart', 'CrmController@panelUserComissionChart');
                    Route::post('panel-user-comission-report', 'CrmController@panelUserComissionReport');
                    Route::post('crypto-status-day-list', 'CrmController@cryptoStatusDayList');
                    Route::post('crypto-status-day-register', 'CrmController@cryptoStatusDayRegister');
                    Route::post('trading-bot-list', 'CrmController@cryptoStatusList');
                    Route::post('kyc-requests', 'CrmController@kycRequests');
                    Route::post('kyc-request-search', 'CrmController@kycRequestSearch');
                    Route::post('kyc-request-approve', 'CrmController@kycRequestApprove');
                    Route::post('kyc-request-deny', 'CrmController@kycRequestDeny');
                    Route::post('kyc-request-report', 'CrmController@kycRequestReport');
                    Route::post('profile-update-requests', 'CrmController@profileUpdateRequests');
                    Route::post('profile-update-request-search', 'CrmController@profileUpdateRequestSearch');
                    Route::post('profile-update-request-approve', 'CrmController@profileUpdateRequestApprove');
                    Route::post('profile-update-request-deny', 'CrmController@profileUpdateRequestDeny');
                    Route::post('profile-update-request-report', 'CrmController@profileUpdateRequestsReport');
                    Route::post('withdraw-requests', 'CrmController@withdrawRequests');
                    Route::post('withdraw-request-approve', 'CrmController@withdrawRequestApprove');
                    Route::post('withdraw-request-deny', 'CrmController@withdrawRequestDeny');
                    Route::post('withdraw-request-report', 'CrmController@withdrawRequestReport');
                    Route::post('bulk-pendings-list', 'CrmController@bulkPendingsList');
                    Route::post('bulk-pendings-chart', 'CrmController@bulkPendingsChart');
                    Route::post('bulk-pendings-report', 'CrmController@bulkPendingsReport');
                    Route::post('bulk-trading-pendings-list', 'CrmController@bulkTradingPendingsList');
                    Route::post('bulk-det', 'CrmController@bulkDetFee');
                    Route::post('bulk-set-pay', 'CrmController@bulkSetPay');
                    Route::post('bulk-update-hash', 'CrmController@bulkUpdateHash');
                    Route::post('bulk-val', 'CrmController@bulkVal');
                    Route::post('bulk-register', 'CrmController@bulkRegister');
                    Route::post('bulk-list', 'CrmController@bulkList');
                    Route::post('bulk-pay-report', 'CrmController@bulkPayReport');
                    Route::post('user-list', 'CrmController@userList');
                    Route::post('user-search', 'CrmController@userSearch');
                    Route::post('user-affiliates', 'CrmController@userAffiliates');
                    Route::post('user-affiliates-report', 'CrmController@userAffiliatesReport');
                    Route::post('user-bonuses', 'CrmController@userBonuses');
                    Route::post('user-bonuses-report', 'CrmController@userBonusesReport');
                    Route::post('user-payments', 'CrmController@userPayments');
                    Route::post('user-payments-report', 'CrmController@userPaymentsReport');
                    Route::post('user-discounts', 'CrmController@userDiscounts');
                    Route::post('user-discounts-report', 'CrmController@userDiscountsReport');
                    Route::post('user-discounts-register', 'CrmController@userDiscountsRegister');
                    Route::post('user-mailing', 'CrmController@userMailing');
                    Route::post('user-purchases', 'CrmController@userPurchases');
                    Route::post('user-purchases-report', 'CrmController@userPurchasesReport');
                    Route::post('user-purchases-pending', 'CrmController@userPurchasesPending');
                    Route::post('user-purchases-pending-report', 'CrmController@userPurchasesPendingReport');
                    Route::post('user-corporative-reg', 'CrmController@userCorporativeReg');
                    Route::post('user-corporative-package-reg', 'CrmController@userCorporativePackageReg');
                    Route::post('user-update', 'CrmController@userUpdate');
                    Route::post('user-node-list', 'CrmController@userNodeList');
                    Route::post('user-register-list', 'CrmController@userRegisterList');
                    Route::post('user-register-report', 'CrmController@userRegisterReport');
                    Route::post('user-register-year-chart', 'CrmController@userRegisterYearChart');
                    Route::post('user-register-year-month', 'CrmController@userRegisterMonthChart');
                    Route::post('user-range-list', 'CrmController@userRangeList');
                    Route::post('user-range-report', 'CrmController@userRangeReport');
                    Route::post('user-range-chart', 'CrmController@userRangeChart');
                    Route::post('user-range-upgrade-list', 'CrmController@userRangeUpgradeList');
                    Route::post('user-range-upgrade-report', 'CrmController@userRangeUpgradeReport');
                    Route::post('user-exceptional-range', 'CrmController@userFlagExceptional');
                    Route::post('accounting-discounts-list', 'CrmController@accountingDiscountsList');
                    Route::post('accounting-discounts-report', 'CrmController@accountingDiscountsReport');
                    Route::post('accounting-deposits-report', 'CrmController@accountingDepositsReport');
                    Route::post('accounting-payments-list', 'CrmController@accountingPaymentsList');
                    Route::post('accounting-payments-report', 'CrmController@accountingPaymentsReport');
                    Route::post('package-list', 'CoreController@packageList');
                    Route::post('multimedia-video-list', 'CrmController@multimediaVideoList');
                    Route::post('multimedia-video-register', 'CrmController@multimediaVideoRegister');
                    Route::post('multimedia-video-status', 'CrmController@multimediaVideoStatus');
                }
            );
        }
    );

    Route::prefix('language')->group(
        function () {
            Route::post('languagesel', 'LanguageController@languageSel');
            Route::post('variablesel', 'LanguageController@variables');
        }
    );

    Route::group(
        ['middleware' => ['jwt.verify']],
        function () {
            Route::prefix('user')->group(
                function () {
                    Route::post('pin', 'UserController@pin');
                    Route::post('search', 'UserController@search');
                    Route::post('sel', 'UserController@sel');
                    Route::post('sid', 'UserController@searchId');
                    Route::post('update-propic', 'UserController@updateProPic');
                    Route::post('update-niname', 'UserController@updateNiname');
                    Route::post('update-language', 'UserController@updateLanguage');
                    Route::post('compound-interest', 'UserController@compoundInterest');
                    Route::post('request-profile-update', 'UserController@requestProfileUpdate');
                    Route::post('update-profile', 'UserController@updateProfile');
                    Route::post('change-password', 'UserController@changePassword');
                    Route::post('kyc', 'UserController@kyc');
                    Route::post('kyc-request', 'UserController@kycRequest');

                    Route::post('affiliates', 'UserController@affiliates');
                    Route::post('affiliates-list', 'UserController@affiliatesList');
                    Route::post('affiliates-list-search', 'UserController@affiliatesListSearch');
                    Route::post('affiliates-search', 'UserController@affiliatesSearch');

                    Route::post('primary-packages-trading', 'UserController@primaryPackageTrading');
                    Route::post('secondary-packages-trading', 'UserController@secondaryPackageTrading');

                    Route::post('active-packages', 'UserController@activePackages');
                    Route::post('active-packages-all', 'UserController@activePackagesAll');

                    Route::post('updatefirstsession', 'UserController@updateFirstSession');

                    Route::post('notifications', 'UserController@notifications');

                    Route::post('refresh-session', 'UserController@refreshSession');
                    Route::post('set-wallet', 'UserController@setWallet');

                    Route::post('payments-history', 'UserController@paymentsHistory');
                    Route::post('range-progress', 'UserController@rangeProgress');

                    Route::post('media-video-list', 'UserController@mediaVideoList');

                    Route::post('income-withdraw-chart', 'UserController@incomeWithdrawChart');
                    Route::post('income-week-chart', 'UserController@incomeWeekChart');
                }
            );
            Route::prefix('trading')->group(
                function () {
                    Route::post('panel-trading-daily-chart', 'CrmController@panelTradingDailyChart');
                    Route::post('trading-daily-week-profit', 'DashboardController@tradingDailyProfit');
                    Route::post('trading-daily-month-week-profit', 'DashboardController@tradingMonthWeekProfit');
                    Route::post('trading-daily-list', 'DashboardController@tradingDailyList');
                }
            );
            Route::prefix('networking')->group(
                function () {
                    Route::post('networking-daily-week-profit', 'DashboardController@networkingDailyProfit');
                    Route::post('networking-profits-history', 'DashboardController@networkingProfitsHistory');
                    Route::post('affiliates-resume', 'DashboardController@affiliatesResume');
                }
            );
            Route::prefix('wallet')->group(
                function () {
                    Route::post('search', 'WalletController@search');
                    Route::post('create', 'WalletController@walletCreate');
                    Route::post('tmp-approve', 'WalletController@tmpApprove');
                    Route::post('tmp-depot', 'WalletController@tmpDeppot');
                }
            );
            Route::prefix('dashboard')->group(
                function () {
                    Route::post('networking-pie', 'DashboardController@networkingPie');
                    Route::post('networking-line', 'DashboardController@networkingBonusLine');
                    Route::post('trading-daily-line', 'DashboardController@tradingDailyLine');
                }
            );
            Route::prefix('deposit')->group(
                function () {
                    Route::post('available', 'DepositController@available');
                    Route::post('start', 'DepositController@start');
                    Route::post('history', 'DepositController@history');
                }
            );

            Route::prefix('purchase')->group(
                function () {
                    Route::post('start', 'PurchaseController@start');
                    Route::post('upgrade', 'PurchaseController@upgrade');
                    Route::post('wallet-upd', 'PurchaseController@updateWallet');
                    Route::post('payment-cnf', 'PurchaseController@paymentCnf');
                    Route::post('expired', 'PurchaseController@paymentExpired');
                    Route::post('/package-prc', 'CoreController@packagePrc');
                    Route::post('/package-upg', 'CoreController@packageUpg');
                    Route::post('form-upd', 'PurchaseController@paymentForm');

                }
            );
            Route::prefix('withdraw')->group(
                function () {
                    Route::post('available', 'WithdrawController@available');
                    Route::post('generate-token', 'WithdrawController@generateToken');
                    Route::post('validate-token', 'WithdrawController@validateToken');
                    Route::post('resend-token', 'WithdrawController@resendToken');
                    Route::post('request', 'WithdrawController@registerRequest');
                    Route::post('history', 'WithdrawController@history');
                    Route::post('date', 'WithdrawController@dateVal');
                }
            );

            Route::post('/input-form-user-validate', 'Controller@inputFormUserValidate');
            Route::post('/packagesel', 'CoreController@packageSel');

            Route::prefix('bybit')->group(
                function() {
                    Route::post('account-register', 'ByBitController@accountRegister');
                    Route::post('account-search', 'ByBitController@accountSearch');
                    Route::post('account-secret-search', 'ByBitController@accountSecretSearch');
                }
            );

        }
    );

    Route::prefix('user')->group(
        function () {
            Route::post('/sign-up', 'UserController@signUp');
            Route::post('/partner', 'UserController@partner');
            Route::post('/activation', 'UserController@activation');
            Route::post('/sign-in', 'UserController@signIn');
            Route::post('/sign-in-token', 'UserController@signInToken');
            Route::post('/sign-in-token-resend', 'UserController@signInTokenResend');
            Route::post('/uservalidate', 'UserController@userValidate');
            Route::post('/resend-code', 'UserController@resendVerificationCode');
        }
    );

    Route::prefix('utils')->group(
        function() {
            Route::post('cur-date', 'Controller@currentDate');
        }
    );

    Route::prefix('password-recovery')->group(
        function () {
            Route::post('request', 'PasswordRecoveryController@request');
            Route::post('token-validation', 'PasswordRecoveryController@tokenValidation');
            Route::post('change', 'PasswordRecoveryController@change');
        }
    );

    Route::prefix('language')->group(
        function () {
            Route::post('default', 'LanguageController@default');
            Route::post('list', 'LanguageController@list');
            Route::post('variables', 'LanguageController@variables');
        }
    );


    Route::prefix('mail')->group(
        function () {
            Route::post('send', 'MailController@sendMail');
        }
    );

    Route::prefix('master')->group(
        function () {
            Route::prefix('country')->group(
                function () {
                    Route::post('list', 'MasterController@countryList');
                }
            );
            Route::prefix('document-type')->group(
                function () {
                    Route::post('list', 'MasterController@documentTypeList');
                }
            );
            Route::prefix('sign-in-method')->group(
                function () {
                    Route::post('list', 'MasterController@signInMethodList');
                }
            );
            Route::prefix('coin-net')->group(
                function () {
                    Route::post('list', 'MasterController@coinNetList');
                }
            );
        }
    );

    Route::post('input-form-validate', 'Controller@inputFormValidate');

    Route::prefix('payment-gateway')->group(
        function () {
            Route::prefix('3a')->group(
                function () {
                    Route::post('/get-token', 'PaymentGatewayController@get3AToken');
                    Route::post('/get-form', 'PaymentGatewayController@getEmbedPaymentForm');
                    Route::post('/status-payment', 'PaymentGatewayController@statusPayment');
                }
            );

            Route::prefix('bb')->group(
                function () {
                    Route::post('/get-form', 'PaymentGatewayController@bbGetEmbedPaymentForm');
                    Route::post('/logs', 'PaymentGatewayController@logsBb');
                    Route::get('/update-status-payment', 'PaymentGatewayController@bbUpdateStatusPayment');
                    Route::post('/estimated-gas', 'PaymentGatewayController@bbEstimatedGas');
                    Route::post('/api-base', 'PaymentGatewayController@apiBase');
                    Route::get('/api-base/update', 'PaymentGatewayController@apiBaseUpdate');
                    Route::post('/walletpaymentdeposit-sel', 'PaymentGatewayController@walletPaymentDepositSel');
                }
            );
        }
    );

    Route::post('app-version', 'Controller@appVersion');
});


